"""
VPN Monitor - MikroTik PPP Connection Logger
=============================================
Consulta periódicamente las conexiones PPP activas vía la API REST de MikroTik
y almacena sesiones, horarios y tráfico en una base SQLite local.

Requisitos:
    pip install requests cryptography

Uso:
    python vpn_monitor.py --setup          # Configurar credenciales (primera vez)
    python vpn_monitor.py --test           # Probar conexión al MikroTik
    python vpn_monitor.py                  # Corre en primer plano
    python vpn_monitor.py --export         # Exporta reporte CSV del último mes
    python vpn_monitor.py --export-daily   # Exporta resumen diario
"""

import requests
import sqlite3
import json
import time
import os
import sys
import logging
import argparse
import getpass
from datetime import datetime, timedelta
from pathlib import Path
import csv
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ─── Rutas ────────────────────────────────────────────────────────────────────

BASE_DIR = Path(__file__).parent
CONFIG_FILE = BASE_DIR / "config.json"
CREDENTIALS_FILE = BASE_DIR / ".credentials.enc"
KEY_FILE = BASE_DIR / ".secret.key"
DB_FILE = BASE_DIR / "vpn_sessions.db"
LOG_FILE = BASE_DIR / "vpn_monitor.log"

DEFAULT_CONFIG = {
    "mikrotik_host": "10.90.0.1",
    "mikrotik_port": 443,
    "mikrotik_user": "api_monitor",
    "use_ssl": True,
    "verify_ssl": False,
    "poll_interval_seconds": 60,
    "dashboard_port": 5555,
    "dashboard_bind": "127.0.0.1",
    "log_level": "INFO"
}

# ─── Logging ──────────────────────────────────────────────────────────────────

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE, encoding="utf-8"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("vpn_monitor")


# ═══════════════════════════════════════════════════════════════════════════════
# CREDENCIALES ENCRIPTADAS
# ═══════════════════════════════════════════════════════════════════════════════

def _get_or_create_key():
    from cryptography.fernet import Fernet
    if KEY_FILE.exists():
        return KEY_FILE.read_bytes()
    key = Fernet.generate_key()
    KEY_FILE.write_bytes(key)
    try:
        import subprocess
        subprocess.run(
            ['icacls', str(KEY_FILE), '/inheritance:r',
             '/grant:r', f'{os.getlogin()}:(R,W)'],
            capture_output=True, check=False
        )
    except Exception:
        pass
    logger.info("Clave de encriptación generada.")
    return key


def save_credentials(user, password):
    from cryptography.fernet import Fernet
    key = _get_or_create_key()
    f = Fernet(key)
    data = json.dumps({"user": user, "password": password}).encode()
    encrypted = f.encrypt(data)
    CREDENTIALS_FILE.write_bytes(encrypted)
    try:
        import subprocess
        subprocess.run(
            ['icacls', str(CREDENTIALS_FILE), '/inheritance:r',
             '/grant:r', f'{os.getlogin()}:(R,W)'],
            capture_output=True, check=False
        )
    except Exception:
        pass
    logger.info("Credenciales guardadas de forma segura.")


def load_credentials():
    from cryptography.fernet import Fernet
    if not CREDENTIALS_FILE.exists() or not KEY_FILE.exists():
        return None
    try:
        key = KEY_FILE.read_bytes()
        f = Fernet(key)
        encrypted = CREDENTIALS_FILE.read_bytes()
        data = json.loads(f.decrypt(encrypted).decode())
        return data
    except Exception as e:
        logger.error(f"Error al leer credenciales: {e}")
        return None


def setup_credentials():
    print("\n" + "=" * 50)
    print("   VPN Monitor — Configuración segura")
    print("=" * 50 + "\n")

    config = load_config(create_if_missing=True)

    print(f"  Host MikroTik actual: {config['mikrotik_host']}")
    new_host = input("  Nuevo host (Enter para mantener): ").strip()
    if new_host:
        config["mikrotik_host"] = new_host

    print(f"  Puerto actual: {config['mikrotik_port']}")
    new_port = input("  Nuevo puerto (Enter para mantener): ").strip()
    if new_port:
        config["mikrotik_port"] = int(new_port)

    print(f"  Usuario actual: {config['mikrotik_user']}")
    new_user = input("  Nuevo usuario (Enter para mantener): ").strip()
    if new_user:
        config["mikrotik_user"] = new_user

    print()
    password = getpass.getpass("  Contraseña del MikroTik: ")
    if not password:
        print("  ERROR: La contraseña no puede estar vacía.")
        sys.exit(1)
    password_confirm = getpass.getpass("  Confirmar contraseña: ")
    if password != password_confirm:
        print("  ERROR: Las contraseñas no coinciden.")
        sys.exit(1)

    save_config(config)
    save_credentials(config["mikrotik_user"], password)

    print(f"\n  OK Configuración guardada en: {CONFIG_FILE}")
    print(f"  OK Credenciales encriptadas en: {CREDENTIALS_FILE}")
    print(f"  CLAVE en: {KEY_FILE}")
    print(f"\n  NO compartas .credentials.enc y .secret.key")
    print(f"\n  Siguiente paso: python vpn_monitor.py --test\n")


# ═══════════════════════════════════════════════════════════════════════════════
# CONFIGURACIÓN
# ═══════════════════════════════════════════════════════════════════════════════

def load_config(create_if_missing=False):
    if not CONFIG_FILE.exists():
        if create_if_missing:
            save_config(DEFAULT_CONFIG)
            return DEFAULT_CONFIG.copy()
        print(f"\n  No se encontró config.json.")
        print(f"  Ejecutá: python vpn_monitor.py --setup\n")
        sys.exit(1)
    with open(CONFIG_FILE, "r", encoding="utf-8") as f:
        config = json.load(f)
    for k, v in DEFAULT_CONFIG.items():
        if k not in config:
            config[k] = v
    return config


def save_config(config):
    safe_config = {k: v for k, v in config.items() if "password" not in k.lower()}
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(safe_config, f, indent=2, ensure_ascii=False)


# ═══════════════════════════════════════════════════════════════════════════════
# BASE DE DATOS
# ═══════════════════════════════════════════════════════════════════════════════

def init_db():
    conn = sqlite3.connect(str(DB_FILE))
    c = conn.cursor()

    c.execute("""
        CREATE TABLE IF NOT EXISTS vpn_sessions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL,
            service TEXT,
            caller_id TEXT,
            assigned_ip TEXT,
            encoding TEXT,
            uptime_raw TEXT,
            connected_at DATETIME,
            last_seen DATETIME,
            disconnected_at DATETIME,
            bytes_in INTEGER DEFAULT 0,
            bytes_out INTEGER DEFAULT 0,
            is_active INTEGER DEFAULT 1,
            mikrotik_id TEXT
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS traffic_snapshots (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id INTEGER,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            bytes_in INTEGER,
            bytes_out INTEGER,
            FOREIGN KEY (session_id) REFERENCES vpn_sessions(id)
        )
    """)

    c.execute("CREATE INDEX IF NOT EXISTS idx_sessions_user ON vpn_sessions(username)")
    c.execute("CREATE INDEX IF NOT EXISTS idx_sessions_active ON vpn_sessions(is_active)")
    c.execute("CREATE INDEX IF NOT EXISTS idx_sessions_connected ON vpn_sessions(connected_at)")

    conn.commit()
    conn.close()
    logger.info("Base de datos inicializada.")


# ═══════════════════════════════════════════════════════════════════════════════
# API MIKROTIK REST
# ═══════════════════════════════════════════════════════════════════════════════

class MikroTikAPI:
    def __init__(self, config, credentials):
        protocol = "https" if config["use_ssl"] else "http"
        self.base_url = f"{protocol}://{config['mikrotik_host']}:{config['mikrotik_port']}/rest"
        self.auth = (credentials["user"], credentials["password"])
        self.verify = config.get("verify_ssl", False)
        self.timeout = 15

    def test_connection(self):
        try:
            resp = requests.get(
                f"{self.base_url}/system/resource",
                auth=self.auth, verify=self.verify, timeout=self.timeout
            )
            resp.raise_for_status()
            return True, resp.json()
        except requests.exceptions.ConnectionError:
            return False, "No se pudo conectar. Verificá IP, puerto y que www-ssl esté habilitado."
        except requests.exceptions.HTTPError as e:
            if e.response.status_code == 401:
                return False, "Usuario o contraseña incorrectos."
            elif e.response.status_code == 403:
                return False, "El usuario no tiene permisos suficientes."
            return False, f"Error HTTP: {e}"
        except Exception as e:
            return False, f"Error: {e}"

    def get_active_connections(self):
        try:
            resp = requests.get(
                f"{self.base_url}/ppp/active",
                auth=self.auth, verify=self.verify, timeout=self.timeout
            )
            resp.raise_for_status()
            return resp.json()
        except Exception as e:
            logger.error(f"Error al consultar API: {e}")
            return None


# ═══════════════════════════════════════════════════════════════════════════════
# PARSING
# ═══════════════════════════════════════════════════════════════════════════════

def parse_uptime(uptime_str):
    if not uptime_str:
        return 0
    total = 0
    parts = uptime_str.strip()
    if "w" in parts:
        w, parts = parts.split("w", 1)
        total += int(w.strip()) * 604800
    if "d" in parts:
        d, parts = parts.split("d", 1)
        total += int(d.strip()) * 86400
    parts = parts.strip()
    if ":" in parts:
        tp = parts.split(":")
        if len(tp) == 3:
            total += int(tp[0]) * 3600 + int(tp[1]) * 60 + int(tp[2])
        elif len(tp) == 2:
            total += int(tp[0]) * 60 + int(tp[1])
    return total


def calculate_connected_at(uptime_str):
    seconds = parse_uptime(uptime_str)
    return datetime.now() - timedelta(seconds=seconds) if seconds > 0 else datetime.now()


# ═══════════════════════════════════════════════════════════════════════════════
# LÓGICA PRINCIPAL
# ═══════════════════════════════════════════════════════════════════════════════

def process_connections(api):
    connections = api.get_active_connections()
    if connections is None:
        return

    conn = sqlite3.connect(str(DB_FILE))
    c = conn.cursor()
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    active_mk_ids = set()

    for vpn in connections:
        mk_id = vpn.get(".id", "")
        username = vpn.get("name", "unknown")
        service = vpn.get("service", "")
        caller_id = vpn.get("caller-id", "")
        address = vpn.get("address", "")
        encoding = vpn.get("encoding", "")
        uptime = vpn.get("uptime", "")
        bytes_in = int(vpn.get("bytes-in", 0) or 0)
        bytes_out = int(vpn.get("bytes-out", 0) or 0)

        active_mk_ids.add(mk_id)
        connected_at = calculate_connected_at(uptime).strftime("%Y-%m-%d %H:%M:%S")

        c.execute("""
            SELECT id, bytes_in, bytes_out FROM vpn_sessions
            WHERE mikrotik_id = ? AND is_active = 1
        """, (mk_id,))
        existing = c.fetchone()

        if existing:
            session_id = existing[0]
            c.execute("""
                UPDATE vpn_sessions SET
                    last_seen = ?, uptime_raw = ?, bytes_in = ?,
                    bytes_out = ?, caller_id = ?
                WHERE id = ?
            """, (now, uptime, bytes_in, bytes_out, caller_id, session_id))
            if bytes_in != existing[1] or bytes_out != existing[2]:
                c.execute("""
                    INSERT INTO traffic_snapshots (session_id, timestamp, bytes_in, bytes_out)
                    VALUES (?, ?, ?, ?)
                """, (session_id, now, bytes_in, bytes_out))
        else:
            c.execute("""
                INSERT INTO vpn_sessions
                (username, service, caller_id, assigned_ip, encoding,
                 uptime_raw, connected_at, last_seen, bytes_in, bytes_out,
                 is_active, mikrotik_id)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)
            """, (username, service, caller_id, address, encoding,
                  uptime, connected_at, now, bytes_in, bytes_out, mk_id))
            logger.info(f"Nueva conexión: {username} ({service}) desde {caller_id}")

    c.execute("SELECT id, username, mikrotik_id FROM vpn_sessions WHERE is_active = 1")
    for session_id, username, mk_id in c.fetchall():
        if mk_id not in active_mk_ids:
            c.execute("UPDATE vpn_sessions SET is_active = 0, disconnected_at = ? WHERE id = ?",
                      (now, session_id))
            logger.info(f"Desconexión: {username}")

    conn.commit()
    conn.close()
    logger.info(f"Poll completado: {len(connections)} conexiones activas.")


# ═══════════════════════════════════════════════════════════════════════════════
# EXPORTACIÓN
# ═══════════════════════════════════════════════════════════════════════════════

def export_report(days=30):
    conn = sqlite3.connect(str(DB_FILE))
    c = conn.cursor()
    since = (datetime.now() - timedelta(days=days)).strftime("%Y-%m-%d")
    output_file = BASE_DIR / f"reporte_vpn_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"

    c.execute("""
        SELECT username, service, caller_id, assigned_ip, connected_at,
            COALESCE(disconnected_at, 'ACTIVO'),
            CASE WHEN disconnected_at IS NOT NULL THEN
                ROUND((julianday(disconnected_at) - julianday(connected_at)) * 24, 2)
            ELSE ROUND((julianday('now','localtime') - julianday(connected_at)) * 24, 2)
            END,
            ROUND(bytes_in / 1048576.0, 2), ROUND(bytes_out / 1048576.0, 2)
        FROM vpn_sessions WHERE connected_at >= ? ORDER BY connected_at DESC
    """, (since,))

    rows = c.fetchall()
    headers = ["Usuario", "Servicio", "IP Pública", "IP Asignada",
               "Conexión", "Desconexión", "Horas", "MB Desc.", "MB Sub."]

    with open(output_file, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        writer.writerow(headers)
        writer.writerows(rows)

    conn.close()
    logger.info(f"Reporte exportado: {output_file} ({len(rows)} sesiones)")
    return output_file


def export_daily_summary(days=30):
    conn = sqlite3.connect(str(DB_FILE))
    c = conn.cursor()
    since = (datetime.now() - timedelta(days=days)).strftime("%Y-%m-%d")
    output_file = BASE_DIR / f"resumen_diario_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"

    c.execute("""
        SELECT username, DATE(connected_at),
            MIN(TIME(connected_at)),
            MAX(COALESCE(TIME(disconnected_at), TIME('now','localtime'))),
            COUNT(*),
            ROUND(SUM(CASE WHEN disconnected_at IS NOT NULL THEN
                (julianday(disconnected_at)-julianday(connected_at))*24
            ELSE (julianday('now','localtime')-julianday(connected_at))*24
            END), 2),
            ROUND(SUM(bytes_in)/1048576.0, 2),
            ROUND(SUM(bytes_out)/1048576.0, 2)
        FROM vpn_sessions WHERE connected_at >= ?
        GROUP BY username, DATE(connected_at)
        ORDER BY DATE(connected_at) DESC, username
    """, (since,))

    rows = c.fetchall()
    headers = ["Usuario", "Fecha", "Primera Conexión", "Última Actividad",
               "Sesiones", "Total Horas", "MB Desc.", "MB Sub."]

    with open(output_file, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        writer.writerow(headers)
        writer.writerows(rows)

    conn.close()
    logger.info(f"Resumen exportado: {output_file} ({len(rows)} registros)")
    return output_file


# ═══════════════════════════════════════════════════════════════════════════════
# API LOCAL PARA DASHBOARD
# ═══════════════════════════════════════════════════════════════════════════════

def start_api_server(port=5555, bind="127.0.0.1"):
    from http.server import HTTPServer, BaseHTTPRequestHandler
    import urllib.parse

    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            parsed = urllib.parse.urlparse(self.path)
            path = parsed.path
            params = urllib.parse.parse_qs(parsed.query)

            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()

            db = sqlite3.connect(str(DB_FILE))
            db.row_factory = sqlite3.Row
            c = db.cursor()

            try:
                if path == "/api/active":
                    c.execute("""SELECT username, service, caller_id, assigned_ip,
                        connected_at, uptime_raw, bytes_in, bytes_out, encoding
                        FROM vpn_sessions WHERE is_active = 1 ORDER BY username""")
                    data = [dict(r) for r in c.fetchall()]

                elif path == "/api/sessions":
                    days = int(params.get("days", [7])[0])
                    user = params.get("user", [None])[0]
                    since = (datetime.now() - timedelta(days=days)).strftime("%Y-%m-%d")
                    q = """SELECT username, service, caller_id, connected_at,
                        disconnected_at, bytes_in, bytes_out,
                        CASE WHEN disconnected_at IS NOT NULL THEN
                            ROUND((julianday(disconnected_at)-julianday(connected_at))*24, 2)
                        ELSE ROUND((julianday('now','localtime')-julianday(connected_at))*24, 2)
                        END as hours FROM vpn_sessions WHERE connected_at >= ?"""
                    b = [since]
                    if user:
                        q += " AND username = ?"
                        b.append(user)
                    q += " ORDER BY connected_at DESC LIMIT 500"
                    c.execute(q, b)
                    data = [dict(r) for r in c.fetchall()]

                elif path == "/api/summary":
                    days = int(params.get("days", [30])[0])
                    since = (datetime.now() - timedelta(days=days)).strftime("%Y-%m-%d")
                    c.execute("""SELECT username, COUNT(*) as sessions,
                        ROUND(SUM(CASE WHEN disconnected_at IS NOT NULL THEN
                            (julianday(disconnected_at)-julianday(connected_at))*24
                        ELSE (julianday('now','localtime')-julianday(connected_at))*24
                        END), 2) as total_hours,
                        ROUND(SUM(bytes_in)/1048576.0, 2) as mb_in,
                        ROUND(SUM(bytes_out)/1048576.0, 2) as mb_out,
                        MIN(connected_at) as first_seen,
                        MAX(COALESCE(disconnected_at, last_seen)) as last_seen
                        FROM vpn_sessions WHERE connected_at >= ?
                        GROUP BY username ORDER BY total_hours DESC""", (since,))
                    data = [dict(r) for r in c.fetchall()]

                elif path == "/api/daily":
                    days = int(params.get("days", [30])[0])
                    since = (datetime.now() - timedelta(days=days)).strftime("%Y-%m-%d")
                    c.execute("""SELECT DATE(connected_at) as date,
                        COUNT(DISTINCT username) as users, COUNT(*) as sessions,
                        ROUND(SUM(CASE WHEN disconnected_at IS NOT NULL THEN
                            (julianday(disconnected_at)-julianday(connected_at))*24
                        ELSE (julianday('now','localtime')-julianday(connected_at))*24
                        END), 2) as total_hours,
                        ROUND(SUM(bytes_in+bytes_out)/1048576.0, 2) as total_mb
                        FROM vpn_sessions WHERE connected_at >= ?
                        GROUP BY DATE(connected_at) ORDER BY date DESC""", (since,))
                    data = [dict(r) for r in c.fetchall()]

                elif path == "/api/users":
                    c.execute("SELECT DISTINCT username FROM vpn_sessions ORDER BY username")
                    data = [r["username"] for r in c.fetchall()]

                elif path == "/api/stats":
                    c.execute("SELECT COUNT(*) as n FROM vpn_sessions WHERE is_active = 1")
                    active = c.fetchone()["n"]
                    c.execute("""SELECT COUNT(DISTINCT username) as n FROM vpn_sessions
                        WHERE DATE(connected_at) = DATE('now','localtime')""")
                    today_users = c.fetchone()["n"]
                    c.execute("""SELECT ROUND(SUM(bytes_in+bytes_out)/1073741824.0, 2) as gb
                        FROM vpn_sessions WHERE DATE(connected_at) = DATE('now','localtime')""")
                    today_gb = c.fetchone()["gb"] or 0
                    data = {"active_now": active, "today_users": today_users,
                            "today_traffic_gb": today_gb}

                elif path == "/api/export":
                    days = int(params.get("days", [30])[0])
                    f = export_report(days)
                    data = {"file": str(f)}

                else:
                    data = {"status": "ok"}

                self.wfile.write(json.dumps(data, ensure_ascii=False, default=str).encode())
            except Exception as e:
                self.wfile.write(json.dumps({"error": str(e)}).encode())
            finally:
                db.close()

        def log_message(self, *args):
            pass

    server = HTTPServer((bind, port), Handler)
    logger.info(f"Dashboard API en http://{bind}:{port}")
    server.serve_forever()


# ═══════════════════════════════════════════════════════════════════════════════
# TEST DE CONEXIÓN
# ═══════════════════════════════════════════════════════════════════════════════

def test_connection():
    config = load_config()
    credentials = load_credentials()
    if not credentials:
        print("\n  No hay credenciales. Ejecutá: python vpn_monitor.py --setup\n")
        return

    print(f"\n  Probando conexión a {config['mikrotik_host']}:{config['mikrotik_port']}...")
    api = MikroTikAPI(config, credentials)
    ok, result = api.test_connection()

    if ok:
        print(f"  OK Conexión exitosa!")
        print(f"     Modelo: {result.get('board-name', '?')}")
        print(f"     RouterOS: {result.get('version', '?')}")
        print(f"     Uptime: {result.get('uptime', '?')}")
        print(f"     CPU: {result.get('cpu-load', '?')}%")
        connections = api.get_active_connections()
        if connections is not None:
            print(f"     VPN activas: {len(connections)}")
        print(f"\n  Todo listo. Ejecutá: python vpn_monitor.py\n")
    else:
        print(f"  ERROR: {result}\n")


# ═══════════════════════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(description="VPN Monitor - MikroTik")
    parser.add_argument("--setup", action="store_true", help="Configurar credenciales")
    parser.add_argument("--test", action="store_true", help="Probar conexión")
    parser.add_argument("--export", action="store_true", help="Exportar reporte CSV")
    parser.add_argument("--export-daily", action="store_true", help="Exportar resumen diario")
    parser.add_argument("--days", type=int, default=30, help="Días para reporte")
    parser.add_argument("--api-only", action="store_true", help="Solo servidor API")
    args = parser.parse_args()

    if args.setup:
        setup_credentials()
        return

    if args.test:
        test_connection()
        return

    config = load_config()
    credentials = load_credentials()

    if not credentials:
        print("\n  No hay credenciales. Ejecutá: python vpn_monitor.py --setup\n")
        sys.exit(1)

    init_db()

    if args.export:
        export_report(args.days)
        return
    if args.export_daily:
        export_daily_summary(args.days)
        return

    port = config.get("dashboard_port", 5555)
    bind = config.get("dashboard_bind", "127.0.0.1")

    if args.api_only:
        start_api_server(port, bind)
        return

    api = MikroTikAPI(config, credentials)
    ok, result = api.test_connection()
    if not ok:
        logger.error(f"No se pudo conectar: {result}")
        sys.exit(1)

    logger.info(f"Conectado: {result.get('board-name','?')} - RouterOS {result.get('version','?')}")

    import threading
    threading.Thread(target=start_api_server, args=(port, bind), daemon=True).start()

    logger.info(f"VPN Monitor iniciado")
    logger.info(f"   MikroTik: {config['mikrotik_host']}:{config['mikrotik_port']}")
    logger.info(f"   Dashboard: http://{bind}:{port}")
    logger.info(f"   Polling cada {config['poll_interval_seconds']}s")

    while True:
        try:
            process_connections(api)
        except Exception as e:
            logger.error(f"Error en polling: {e}")
        time.sleep(config["poll_interval_seconds"])


if __name__ == "__main__":
    main()
