@echo off
chcp 65001 >nul
title VPN Monitor - MikroTik

echo.
echo  ══════════════════════════════════════════
echo     VPN Monitor - MikroTik
echo  ══════════════════════════════════════════
echo.

:: Verificar Python
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo  [ERROR] Python no encontrado.
    echo  Descargalo de https://python.org
    echo  IMPORTANTE: Marcar "Add Python to PATH"
    pause
    exit /b 1
)
echo  [OK] Python encontrado.

:: Instalar dependencias
echo  Instalando dependencias...
pip install requests cryptography >nul 2>&1
echo  [OK] Dependencias instaladas.
echo.

:: Verificar si hay credenciales
if not exist ".credentials.enc" (
    echo  Primera vez? Vamos a configurar las credenciales.
    echo.
    python vpn_monitor.py --setup
    echo.
    echo  Ahora probamos la conexion:
    echo.
    python vpn_monitor.py --test
    echo.
    echo  Si la conexion fue exitosa, ejecuta este .bat de nuevo
    echo  para iniciar el monitoreo.
    pause
    exit /b 0
)

echo  [OK] Credenciales encontradas.
echo.
echo  Iniciando VPN Monitor...
echo  - Dashboard: http://localhost:5555
echo  - Abrir dashboard.html en el navegador
echo  - Presionar Ctrl+C para detener
echo  - Logs en: vpn_monitor.log
echo.

python vpn_monitor.py

pause
