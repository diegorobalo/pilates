# VPN Monitor — MikroTik

Sistema de monitoreo y auditoría de conexiones VPN para MikroTik.
Registra sesiones, horarios de conexión/desconexión y tráfico de datos.

---

## 📋 Requisitos

- **Python 3.8+** instalado en Windows ([descargar](https://python.org))
  - Marcar "Add Python to PATH" durante la instalación
- **MikroTik RouterOS 7+** con API REST habilitada
- Acceso de red desde la PC al router MikroTik

## 🚀 Instalación rápida

1. Copiar toda la carpeta `vpn_monitor` a la PC/servidor Windows
2. Ejecutar `instalar_y_ejecutar.bat` (doble clic)
3. Editar `config.json` con los datos de tu MikroTik:

```json
{
  "mikrotik_host": "10.90.0.1",
  "mikrotik_port": 443,
  "mikrotik_user": "api_monitor",
  "mikrotik_password": "contraseña_segura",
  "use_ssl": true,
  "verify_ssl": false,
  "poll_interval_seconds": 60
}
```

4. Volver a ejecutar `instalar_y_ejecutar.bat`

## 🔧 Configurar MikroTik

En tu MikroTik (Winbox o terminal):

```mikrotik
# Crear usuario solo para monitoreo (read-only)
/user add name=api_monitor password=contraseña_segura group=read

# Habilitar API REST (RouterOS 7+)
/ip/service set www-ssl disabled=no port=443

# Si usás RouterOS 6, necesitás habilitar la API clásica:
/ip/service set api disabled=no port=8728
```

## 📊 Dashboard Web

1. Con el monitor corriendo, abrir `dashboard.html` en el navegador
2. Verificar que la URL del API sea `http://localhost:5555`
3. Los datos se actualizan cada 60 segundos automáticamente

## 📥 Exportar Reportes

### Desde línea de comandos:
```bash
# Reporte detallado (últimos 30 días)
python vpn_monitor.py --export

# Reporte detallado (últimos 90 días)
python vpn_monitor.py --export --days 90

# Resumen diario por usuario
python vpn_monitor.py --export-daily
```

### Desde el dashboard:
Usar el botón "Exportar CSV" en la esquina superior derecha.

## 🔄 Ejecutar como servicio (opcional)

Para que corra automáticamente al iniciar Windows, usar el
Programador de Tareas de Windows:

1. Abrir "Programador de tareas" (Task Scheduler)
2. Crear tarea básica → Nombre: "VPN Monitor"
3. Desencadenador: "Al iniciar el equipo"
4. Acción: "Iniciar un programa"
   - Programa: `python`
   - Argumentos: `C:\ruta\a\vpn_monitor\vpn_monitor.py`
   - Iniciar en: `C:\ruta\a\vpn_monitor\`
5. Marcar "Ejecutar tanto si el usuario inició sesión como si no"

## 📁 Archivos generados

| Archivo | Descripción |
|---------|-------------|
| `vpn_sessions.db` | Base de datos SQLite con todas las sesiones |
| `vpn_monitor.log` | Log de actividad del monitor |
| `config.json` | Configuración del router |
| `reporte_vpn_*.csv` | Reportes exportados |
| `resumen_diario_vpn_*.csv` | Resúmenes diarios exportados |

## 🔍 Endpoints de la API

| Endpoint | Descripción |
|----------|-------------|
| `GET /api/active` | Conexiones activas ahora |
| `GET /api/sessions?days=30` | Historial de sesiones |
| `GET /api/summary?days=30` | Resumen por usuario |
| `GET /api/daily?days=30` | Resumen diario |
| `GET /api/users` | Lista de usuarios |
| `GET /api/stats` | Estadísticas generales |
| `GET /api/export?days=30` | Genera y devuelve CSV |

## ❓ Preguntas frecuentes

**¿Qué pasa si el monitor se detiene?**
Se pierden las desconexiones durante ese período, pero al volver a
correr retoma el registro normalmente.

**¿Puedo ver la base de datos con otra herramienta?**
Sí, `vpn_sessions.db` es SQLite estándar. Podés abrirla con
DB Browser for SQLite, DBeaver, o cualquier herramienta compatible.

**¿El tráfico reportado es exacto?**
Es el tráfico que reporta MikroTik por la interfaz PPP. Es preciso
para el tráfico que pasa por el túnel VPN.
