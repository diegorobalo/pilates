(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"chica_escritorio_sentada_atlas_1", frames: [[0,0,1603,1832]]},
		{name:"chica_escritorio_sentada_atlas_2", frames: [[922,0,1068,801],[823,1311,686,657],[0,0,920,1210],[0,1212,821,809],[922,803,1070,506]]},
		{name:"chica_escritorio_sentada_atlas_3", frames: [[1186,1262,488,503],[1320,624,599,636],[0,0,946,472],[0,474,696,601],[698,624,620,615],[723,1241,461,589],[1676,1262,367,651],[0,1241,721,427],[948,0,689,622]]},
		{name:"chica_escritorio_sentada_atlas_4", frames: [[1417,426,531,209],[1994,368,52,5],[629,535,206,260],[904,0,560,338],[0,409,389,370],[904,340,511,301],[837,643,170,89],[1935,368,57,10],[391,409,122,69],[2000,0,7,8],[1870,224,157,142],[1870,368,63,40],[0,0,530,407],[1417,637,503,112],[391,535,236,265],[532,0,370,533],[1870,0,128,222],[1466,0,402,424]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_47 = function() {
	this.initialize(ss["chica_escritorio_sentada_atlas_3"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_46 = function() {
	this.initialize(ss["chica_escritorio_sentada_atlas_2"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_45 = function() {
	this.initialize(ss["chica_escritorio_sentada_atlas_2"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_44 = function() {
	this.initialize(ss["chica_escritorio_sentada_atlas_3"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_24 = function() {
	this.initialize(ss["chica_escritorio_sentada_atlas_4"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_43 = function() {
	this.initialize(ss["chica_escritorio_sentada_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_22 = function() {
	this.initialize(ss["chica_escritorio_sentada_atlas_4"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_21 = function() {
	this.initialize(ss["chica_escritorio_sentada_atlas_4"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_42 = function() {
	this.initialize(ss["chica_escritorio_sentada_atlas_4"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_41 = function() {
	this.initialize(ss["chica_escritorio_sentada_atlas_3"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_40 = function() {
	this.initialize(ss["chica_escritorio_sentada_atlas_4"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_39 = function() {
	this.initialize(ss["chica_escritorio_sentada_atlas_2"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_16 = function() {
	this.initialize(ss["chica_escritorio_sentada_atlas_3"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_38 = function() {
	this.initialize(ss["chica_escritorio_sentada_atlas_3"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_37 = function() {
	this.initialize(ss["chica_escritorio_sentada_atlas_4"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_36 = function() {
	this.initialize(ss["chica_escritorio_sentada_atlas_4"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_12 = function() {
	this.initialize(ss["chica_escritorio_sentada_atlas_4"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_35 = function() {
	this.initialize(ss["chica_escritorio_sentada_atlas_4"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_10 = function() {
	this.initialize(ss["chica_escritorio_sentada_atlas_4"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_34 = function() {
	this.initialize(ss["chica_escritorio_sentada_atlas_4"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_33 = function() {
	this.initialize(ss["chica_escritorio_sentada_atlas_3"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_32 = function() {
	this.initialize(ss["chica_escritorio_sentada_atlas_3"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_6 = function() {
	this.initialize(ss["chica_escritorio_sentada_atlas_4"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_31 = function() {
	this.initialize(ss["chica_escritorio_sentada_atlas_4"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4 = function() {
	this.initialize(ss["chica_escritorio_sentada_atlas_4"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_30 = function() {
	this.initialize(ss["chica_escritorio_sentada_atlas_4"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_29 = function() {
	this.initialize(ss["chica_escritorio_sentada_atlas_2"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_1 = function() {
	this.initialize(ss["chica_escritorio_sentada_atlas_4"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.Mesh = function() {
	this.initialize(ss["chica_escritorio_sentada_atlas_3"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.Mesh_0 = function() {
	this.initialize(ss["chica_escritorio_sentada_atlas_2"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.Mapadebits6 = function() {
	this.initialize(ss["chica_escritorio_sentada_atlas_4"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.Mapadebits7 = function() {
	this.initialize(ss["chica_escritorio_sentada_atlas_4"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.Mapadebits8 = function() {
	this.initialize(ss["chica_escritorio_sentada_atlas_3"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.sombra_ventana = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.Mapadebits8();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.sombra_ventana, new cjs.Rectangle(0,0,689,622), null);


(lib.sombra_chica = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.Mapadebits7();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.sombra_chica, new cjs.Rectangle(0,0,402,424), null);


(lib.sombra = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.Mapadebits6();
	this.instance.setTransform(0,9.8,1.7901,2.2772,0,-0.8185,-2.4505);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.sombra, new cjs.Rectangle(0,0,236.1,515.3), null);


(lib.Path_18 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#8A8D8D").s().p("EgRzA5+Qgc8egV8kUgAqg5IAAjgAhQAjgiR+lGQI/ikI4idMABOCGtg");
	this.shape.setTransform(121.1546,431.05);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_18, new cjs.Rectangle(0,0,242.3,862.1), null);


(lib.Path_16 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#C2B0A0").s().p("Eg4kAG/MBxJgXtIhEEbMhlQAU4IpNIKg");
	this.shape.setTransform(362.075,107.05);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_16, new cjs.Rectangle(0,0,724.2,214.1), null);


(lib.Path_9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#A5B8BA").s().p("A42fdMgAFg+vIBogKMAwLAH9IAEHCIiICQIg8gCMgqOApAIgNBpIiqDDg");
	this.shape.setTransform(159.625,201.325);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_9, new cjs.Rectangle(0,0,319.3,402.7), null);


(lib.Path_8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#A4D3DB").s().p("Avt2cIfbAAMAAAAsVI/bAkg");
	this.shape.setTransform(100.575,143.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_8, new cjs.Rectangle(0,0,201.2,287.4), null);


(lib.Path_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#6BD0CC").s().p("AD3FrIAUgMQAqgbAEghQALgvAAgLQABgPgeAEQglAFh8hHQiAhJhrhbQhdhOiRiRQhJhIg3g5QApgDAqAAQBSAAAnAQQAsASAMALQAFAEAcAmQAwBBBeBpQCACQBIAxQBGAvBmAqQAzAVAlAMIAVAJQAUAMgCANQgDAWgfA+QiPAegkAGIgHABQgBAAAAAAQAAAAAAAAQAAAAAAgBQAAAAABAAg");
	this.shape.setTransform(46.7589,36.4694);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_1, new cjs.Rectangle(0,0.1,93.5,72.80000000000001), null);


(lib.Path = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E9C7AA").s().p("ADaDjQgxh5g1gjQgsgdiGgvQh8gsgXgVQgwgsgGgbQgMg4Azh6QgHATgBAbQgDA1AaAnQAZAlBHgPIA8gPQAlgKAVgBQAzgDA3ApQAwAkApA8QAgAuAUBeQAKAvAEAnIgGA/QgGBCAAAQQgMgigYg7g");
	this.shape.setTransform(26.652,32.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path, new cjs.Rectangle(0.1,0,53.199999999999996,64.1), null);


(lib.Path_126 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#59534F").s().p("EApEAKVIigguQj7hJkVgUQkBgTmEArQizAUhBADQh2AGhHgSQiZgmjXgEQjKgDjPAbQikAWpPAoIotAjQiqg7lngzQrNhluqAsQkkAOo6hOImfg8QjXgehigFQjZgKibgJQkigQi+gUQo+g/DghwQByg5D1hEQAmgLGIhlQDxg/BWglQB1gxhDglQhJgogKgXQgJgXAygUQAqgQB6gbIEdg/IH1hEQIxhCEqALQD0AJEyAsQEiApC2AEQC7AEG8gbQF+gMCEBFQCuBcEcAmQE3AqFQgmQEngiNBAnQGhAUFmAaIBqA1IqOAAIBJAKQBXAMBDAOQDZAsg3AsQg4AsDQgJQBogEBzgNIJfBGQKSBQD+ArQCSAaHRBrQFaBPB4AAQBdAAHWAqQGuAmBDgJQBNgLDXAUQBrAKBbAMQAGADgFAHQgLAMg4ANQizAqozAhQozAhouAVIm+AOIECAjQDjApiaAhQieAhpLANQkyAHmOAAQg/AAhPgUg");
	this.shape.setTransform(626.6107,68.1214);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_126, new cjs.Rectangle(0,0.1,1253.3,136.1), null);


(lib.Path_125 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#59534F").s().p("EgiaAF3QlGgrFGhSQCqgqFAgzQB0gYJBhNQJchQChgJQBSgFgXgbQgVgYhigiQjhhQjpgVQjOgTAsgsQAmglCygkQCDgaBBAXQAnANBBAtQA/AfEbArQEeAtBZgLQBNgIJogfIJZgdIh6BtIkbA8QkQA6AzgJQAegFH8gKQIAgKBrgQQB4gRgpBLQgUAlgtApQjaA2hSAOQhTAOi9AtQjMAyA2AAQApAADigIQDtgDCWAYQEGArAbAXQAXATiRAHQhjAEjoAAQkZgBg7ABQiNAClhgyQmOg5hLgEQhFgEhrgbIjHg1QkKhEi9AQQj3AUjPAdQjSAch+AgQguALjVBRQinA/h3AIQjMAOl+AAg");
	this.shape.setTransform(236.5766,37.5281);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_125, new cjs.Rectangle(0,0.1,473.2,74.9), null);


(lib.Path_124 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3C3831").s().p("EgE9AsjQgBhZAbiKQAOhEgkgbQgfgXglASQgPAIgkgLQglgLgcgWQhMg+BIhIQBEhEgNhpQgDgZgPhDQgOg8gDgjQgFhJjKi2IiQiDQhFhBgKgdQgFgQAFgUQg4Asg2AgQjSB7iAhkQhphRgbjKQgslWgbi3Qg1lsgahHQgZhEgogNQgMgEgNACQgGABgEACQgPjXgIjrQgSnYAfhrQAhhuBQg9QAdgWAvgZIBRgqIGBjVQEzirASgGQAWgHgEhPQgEhJgYhvQgVhjAEhEQADg6AYhBQAUg1gMhzQgIhLgeiTQgShdAghEQAKgVAOgQIAMgMIBaCgQgHhGgDhPQgFieAagtQAZgtgUg4IgagvQChgXDAgRQDDgRAWAHQATAHAcGIQANDEAKDDIgeS6IhBJSQhBJpAAB2QAABKA9E3QBAFGBTFZQDiOcB9BQQB5BMLWhGIB+gNQENg5CAgGQBhgEi3AbQiLAVisATIhdAVIk2BMIu1GuQgWAAgnAFQhNAKhSAZQgMAEgLAAQg9AAgCh/g");
	this.shape.setTransform(177.1781,297.7562);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_124, new cjs.Rectangle(0,-0.1,354.4,595.7), null);


(lib.Path_78 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#60502E").s().p("AgIAmQgQgHgEgbQgZgHgSAKQgMAHgBgGQgDgPAOgWIAFgCQAcgLA8AEQA6AEAFAIQAHALgJAjQgFgJgGgFQgNgJgHARQgGATgTAEIgTABIgGACQgEAAgEgCg");
	this.shape.setTransform(8.7916,3.9516);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_78, new cjs.Rectangle(0.2,0,17.2,7.9), null);


(lib.Path_77 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#60502E").s().p("AACAgQgCgGgCgNQgBgGgJABQgKABgGAJIgDAHIgCgOQgDgQAIggIAFAAQAQgHAWAGQAMADAIAEQgBAqgEAQQgDANgIACIgDAAQgHAAgHgKg");
	this.shape.setTransform(3.4591,4.1998);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_77, new cjs.Rectangle(0,0,7,8.4), null);


(lib.Path_76 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E3E2E7").s().p("AgxAVQgDgKAAgPQAAgOAIgGQA9gOAgASQAIAFgKAFQgJAFgcAGQgUAFgMAIIgRAPQAAAAgBABQAAAAgBAAQAAABgBAAQAAAAgBAAQgEAAgCgKg");
	this.shape.setTransform(5.2651,3.0638);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_76, new cjs.Rectangle(0,0,10.6,6.2), null);


(lib.Path_75 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E3E2E7").s().p("AgSAZQgHgIACgaQAAgLAFgDQATgEAJAEQAFADAGAGQAGAEgEAGQgDAEgJAGIgQAPQgGAFgEAAQgBAAAAAAQgBAAAAAAQAAAAgBgBQAAAAAAAAg");
	this.shape.setTransform(2.3857,2.5904);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_75, new cjs.Rectangle(0,0,4.8,5.2), null);


(lib.Path_69 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#AC7AB7").s().p("AgiaqIhokjQg0iUgSgiQgjhCh7lxIhzljICR68ICxpoIBeDdICYBGQgKAygKBLQgFAmgPClQgSCngWBfQgHAfgMBSQgMBKgNA1QgsCrh+D5Qg0BoAqCcQAsCfBqA3QBKAnBMgGIAagMQAxgVAYAAQAIAAgUALQgWALgfAGQgRAEgRABQg2AcgpAsQg4A9AKAbQAKAYA3gMQAtgJgHAUQgEANgdAuQgUAsADANQADARAsgOQAxgPAbASQAbARgXAeQgTAaAbgDQAUgDBSgUQBfgUB9gKIh+A4QiCA7gTAPQghAcgEA2QgFBDBIAaQBJAbAAAVQAAAJgLAOIgWAdQgRAaBBAvQBLA2ACAIQAKAeBkB4QgrALg5AaQhwAzg/BIQhGBRg9B8Qg3BxgJA+QgGAvAKBOQAFAoAGAeg");
	this.shape.setTransform(48.225,189.775);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_69, new cjs.Rectangle(0,0,96.5,379.6), null);


(lib.Path_68 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D3B69B").s().p("A2oJUQh4gJhMhsQgfgtg8irQhDjKgehSIIPo+QAIACBgBAQB3BQBkA4QFhDHElAcQFWAgIdADQIJACDQgaQCsgVB3hDQBSgtARgiQAHgOAngsIAmgqIBTIrQqiCnhqAMQm0AtrdBQQxNB4g4AOQhoAZg4AAIgPAAg");
	this.shape.setTransform(183.3,59.5992);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_68, new cjs.Rectangle(0,0,366.6,119.2), null);


(lib.Path_66 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D3B69B").s().p("AlkOQQgMg4BNi+QAbixAOhKQAWh3gGg3QgCgRgFgJIgEgFIhEAdQhGApgHAxQgKBRAUkdQARgPAegMQA8gYBEAQIBMASQAlh3AniEQBOkLAJhGQAPhuAAg7IFZkTQgXBbgjBvQhGDeg5BkIiYEzQidFCgjBQQgbBChwD4IgRArIgRBpQgbCagOAAQgEABgDgOg");
	this.shape.setTransform(39.3833,92.5499);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_66, new cjs.Rectangle(0,0,78.8,185.1), null);


(lib.Path_47 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3C3831").s().p("AZCJGQgXAAgsg/IhhiWQidjtiVhQQithciDgcQg5gNh3gRIkOgnQmjhLitgUQkcghitA6QkOBap8DmQgnAYg2ABQhtAChSh3QhRh1g6kHQgdiDgMhrQAZBVBRBWQCjCtEZAGQEEAGGvhAIE1guQCegXBSgDQB7gFGvBRQG+BUDHAAQDCAAEjheQB1gmAkgFQA8gJAKAiQAgBmCMFnIDOHSQlugQhGAAg");
	this.shape.setTransform(203.825,59.825);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_47, new cjs.Rectangle(0,0,407.7,119.7), null);


(lib.Path_46 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D3B69B").s().p("AMXDXQiOgoiQgZQiPgZqHgKQlEgFknAAQCqg8LakrQgjAegkAtQhIBagHBLQgHBSEdgHQEGgGC9g8ICCgqQA1gSATgCQAYgDAIAOQAGANAAAmQAAA+AtBkQAWAyAXAmQgrgPhHgUg");
	this.shape.setTransform(90.5,24.975);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_46, new cjs.Rectangle(0,0,181,50), null);


(lib.Path_44 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#798C8F").s().p("ApwNYQArgDAxgJQBlgSAqgfQAvgiAMgvQAJgigGg0QgEgrgWgxQgUgxgcghQgXgbgogRIgkgLIgGxxIBEh8IAdD4IAAPWIgEAAQgBAAAAABQAAAAAAAAQAAAAABABQABAAABAAQANAFBOALQBMAMA1AzQAbAaAKAXIFTgNIG4BEQjFgEjMgDQmXgEgnALQgpANgMAmQgIAbAFA0QAFAjA4AFQAdACAcgFIgyAlQg6AsgvAfQgtAfiJAAQhEAAg7gHg");
	this.shape.setTransform(62.45,86.275);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_44, new cjs.Rectangle(0,0,124.9,172.6), null);


(lib.Path_39 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#AC7AB7").s().p("AHZEiQjMhihxgHQhxgGjBANQhhAGhKAIQBHgVBlgUQDJgoCSAHQCtAIAQgaQAPgbihgIIm9gVQBPgLBhgJQDBgTBWAHQAxAEAVgVQASgSgLgdQgLgdghgVQglgXgxAAQhkAAAFgkQAEgjBbgZQAqgLgEgKQgDgJgngDQhhgIh5AfQiCAgjSAlQjVAlg/AAQgwAAB5ghQDMg4A0gRQAtgbA8gdQB4g6BJgOQB0gVE6gUQARBgAVBpQAqDTAUA1QAfBVBrDfQhQgwhmgxg");
	this.shape.setTransform(65.7832,38.675);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_39, new cjs.Rectangle(0.3,0,131,77.4), null);


(lib.Path_38 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#AC7AB7").s().p("AqvDTQA7hAAngNQBZgmBBgVQB9goBdAOQBrAPD0goQBhgQArgNQAugPgxgEQirgLhFgFQh7gJBDgHIGngrQgggQg6gRQh1giiEgHQh4gGkLAzIiZAeQg5AKANgLQARgNBageQBhggBxgdQE0hPCgAOQCaANAxAlQAQAMAMAVQAQAZAIAIQArArC0B+IifA1QgjgFhLgCQiYgCjNATQjNAUjiAoQhxAUhIAQQgagNhqA1Qg1AbgwAdQAWgdAcggg");
	this.shape.setTransform(73.8,27.1446);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_38, new cjs.Rectangle(0,0,147.6,54.3), null);


(lib.Path_35 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#8C4D4C").s().p("AiaEmQgDhHABgIQADgNhDi2IgSidQgRijgBgRQABgSAUgQQALgHALgFQgQALgFATQgCAKABAIIAcE3IAjAOQAnAcAVA7QAVA8AHAuQAEAYgBALICEhkQCJhnAUgLQATgLAMgVQAGgLACgJIAJAcIiEB1QiGB4gKALQgPAShzBiIgEhGg");
	this.shape.setTransform(25.65,36.375);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_35, new cjs.Rectangle(0,0,51.3,72.8), null);


(lib.Path_27 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ah/ChQAogVBOiYQAlhNAfhIQAiAFAVALQAKAGAEAEQgMBAgcBAQgcA/gyBdQhHANg2AAIgMgBg");
	this.shape.setTransform(12.775,16.1573);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_27, new cjs.Rectangle(0,0,25.6,32.3), null);


(lib.Path_26 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgxCCQAhgfAMh3QAFg8gBg1QAqATAGAaQAEAOgFBTQgDA9gOAbQgGAOgGACQgGAIgLAGQgMAHgPAAQgLAAgMgEg");
	this.shape.setTransform(4.9766,13.4012);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_26, new cjs.Rectangle(0,0,10,26.8), null);


(lib.Path_25 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhhB4QgTgZgKgiQgLgnAHgpQAGgpAUgVQAQgSAzgRQAagIAVgFQA6gIBCAAQgsAUgwAbQhfA4gVAlQgVAnAFA0QADAaAHASQgIgGgJgMg");
	this.shape.setTransform(13.4176,13.825);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_25, new cjs.Rectangle(0.1,0,26.7,27.7), null);


(lib.Path_23 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#798C8F").s().p("AFYDRIgwgHQgCgUgGgiQgNhCgWg/QgahIg8g0Qg5gzhIgQQhagWmBgSQHGAFBtANQBMAJBOA8QBDAzApA/QAkA3ALBTQAKBRgaADIgSABQgWAAgjgDg");
	this.shape.setTransform(43.774,21.25);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_23, new cjs.Rectangle(0,0,87.6,42.5), null);


(lib.Path_20 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#798C8F").s().p("AESDpQhtgzgGgYQgHghgBg3QgBg9AJgmQAKgqggg1Qghg0gkgGQgxgJmRhYQGFAoBXARQBXASAcALQAwATgKAfQgOAogbBGQgSA8AGA0QAFAkALgQQAHgMAPgyQAsiOAPgVQAWghgLA/QgaCDgDAWQgIBFASAnQALAWAXAbQARAfAxAjQg2gVg3gag");
	this.shape.setTransform(38.25,27.975);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_20, new cjs.Rectangle(0,0,76.5,56), null);


(lib.Path_19 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD9BE").s().p("AgVFHQAYgfAGgbQAJgngChlQgCh7gRh5QgShygshJQgXgkgSgOQCFAXA1BYQAbAsAAAoIhFhdQASDfAECGQAEBUgVBOQgKAngKAWIhFAXQAMgKANgQg");
	this.shape.setTransform(10.7,35.325);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_19, new cjs.Rectangle(0,0,21.4,70.7), null);


(lib.Path_17 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#798C8F").s().p("Ar4E2QAKhlAdhKQAhhUAmgzQAqg4BAgpQA3giBxgcQA4gOAtgHQg1ALg/AcQh8A3grBSQgpBNAJBDQAEAcAPgCQAQgBAZgnIA6hvQAVglA4gqQA+guCMgtQBrgiBjgTQA1gKE0gvIEogvQARgFgDgPQgCgRgzAGIjbAcIFYhYQAFAGACAJQAFAUgMAUIguBUQpvBihqAXQhSASh1ArQh3AsgRAUQgXAcghA7QgoBIgGAoQgJA+gIAaQgOAsgZAWQgYAVhnAaQhbAWgXAAQgQAAAJheg");
	this.shape.setTransform(76.348,40.425);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_17, new cjs.Rectangle(-0.1,0,152.9,80.9), null);


(lib.Path_14 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#338560").s().p("AkLCuQANhzATgsQAag8AhgmQAsgxBUgyQBMgsCEgeQBCgQAygGQhSAThbAiQi0BFgqBMQgVAphFBgQgpA5AAAmQAAAggJAUQgMAZgFAyQADgwAGg5g");
	this.shape.setTransform(27.65,27.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_14, new cjs.Rectangle(0,0,55.3,55.8), null);


(lib.Path_8_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#AC7AB7").s().p("ADRFIQhKiwg8hhQgVgkAEgWQAGgkgBgGQgLhJjWj3QgggjhNhUIHmEZQgIA0gHA/QgOB7ADA4QADA3ApCuQAUBYATBNQgZhFgmhYg");
	this.shape_1.setTransform(27.225,48.45);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_8_1, new cjs.Rectangle(0,0,54.5,96.9), null);


(lib.Path_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#6BD0CC").s().p("At7C3QgEgeAAggQABhAAZgNQAYgOAbgBQAOAAAJACIATATQAaAUAhAIQAhAJBbgRQAzgJBjgWQA3gLB4AQQA8AIAyAKIBnkBIEBBbQEaBfB9AaQA1AMClAXQBFAKAAAZQAAAiggAfQghAggsADQg9AE13AFg");
	this.shape.setTransform(89.5725,19.575);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_5, new cjs.Rectangle(0,0,179.2,39.2), null);


(lib.Path_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E9C7AA").s().p("Ak8EAQgMgHgFgLIgEgIQAHg9gIheQgSi6hMijQCHCyA4BTQArA+BMAKQBPALAdg6QAQgjgPhnQgFgjAEgHQAGgJAbAZQCmCVAwAAQBjgDA6goQAdgUAJgTIAFgGIgeBeIhnECQiBgOg0gJQgegFhjAPQibAWggADQgUACgRAAQg2AAgcgTg");
	this.shape.setTransform(43.3,27.522);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_4, new cjs.Rectangle(0,0,86.6,55.1), null);


(lib.Path_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3C3831").s().p("AFvOqQgpikgwixQhglhgkg/QgXgZgtgWQhYgshrANQhrANjdgFQhvgChZgGQCBgTCRgaQEjg0BTgeQBcgiAWjSQASi3gniCQgdhgh0hyQhphmgogCIA1ABQBSgCA4gNQAlgIAxgZQAegKAFArQAVFeAOBrQALBMA9FPQAJA2BwErQB+FSA7BKQA6BHAfBEQAPAiADATIAHAdg");
	this.shape.setTransform(64.55,94.5729);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_3, new cjs.Rectangle(0,0.1,129.1,189), null);


(lib.Path_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#6D5C33").s().p("AgpAJIApg9IBEAAQgRABgXAJQgsATgcArIgXAhQgBAAAbgsg");
	this.shape.setTransform(6.4863,5.2653);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_2, new cjs.Rectangle(-0.3,0,13.600000000000001,10.6), null);


(lib.Path_1_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#6D5C33").s().p("AgVgRIA9ALQgQAAgTADQgRACgcATg");
	this.shape_1.setTransform(4.05,1.75);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_1_1, new cjs.Rectangle(0,0,8.1,3.5), null);


(lib.Path_6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#6D5C33").s().p("AgGgZIAoAbIgTAAQgSgBgeAZg");
	this.shape_1.setTransform(3.375,2.55);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_6, new cjs.Rectangle(0,0,6.8,5.1), null);


(lib.ClipGroup = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EAFJAugQkPgGj0klQhahrhfidQgshJhji0Qg9htiCmCQh+lyiFnFQiNnehUlhQhgmNAGh6QAKjiDmktQCTjBDkjSQByhqByn2IBSl7QAtjHAfhKQBAiWD/hPQCAgnB0gKIGCDRIE6VPMAEnA+XQiGBli5BjQlqDCkAAAIgOgBg");
	mask.setTransform(577.91,499.3074);

	// Capa_3
	this.instance = new lib.CachedBmp_43();
	this.instance.setTransform(255.7,79.2,0.5,0.5);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup, new cjs.Rectangle(449.9,201.7,256.1,595.3), null);


(lib.Path_20_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#C3D3D6").s().p("A7wtRMA3hgEEIgRbfMg3QAHMg");
	this.shape_1.setTransform(177.675,110.975);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_20_1, new cjs.Rectangle(0,0,355.4,222), null);


(lib.Path_19_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#A6B4B7","#A6B4B7"],[0,0.945],-187.5,0,187.5,0).s().p("A9MD/QgLhdAJh1QAJh0BPhLQAoglAmgOMA37gB9QgaARgjAeQhHA7gwA9QgwA9gCCRQgBBJAJA8Mg21ACLQgHgWgFgug");
	this.shape_1.setTransform(187.5349,32.325);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_19_1, new cjs.Rectangle(0,0,375.1,64.7), null);


(lib.Path_18_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#A6B4B7","#A6B4B7"],[0,0.945],-186.5,0,187.7,0).s().p("A4gEJQhigggYACQklAdClgSQgFhTAAhaQAAi0AbgoQAeguBug1QBog0AwABQAlABZsBFIZlBFIBAAVIgOD6QgEg9gPglQgghJg8B3QgNANABAGQABADAEAAMgyUADXQgtgQgxgRg");
	this.shape_1.setTransform(186.5028,29.799);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_18_1, new cjs.Rectangle(-1.3,0,375.6,59.6), null);


(lib.Path_16_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#A6B4B7","#A6B4B7"],[0,0.945],-502.8,0,502.9,0).s().p("AMvA5Qg3guhCggIg2gXMhU2gDIQhiAGhGgCQiMgECKglQCJgmZjhBQMyggMWgZQVUAoWfAoUAtAABQAF4AAAQHOAABLEOQAYBTgSBlQgJAzgOAiQvmAovnAsQ/OBWgGAOQgGjrixiWg");
	this.shape_1.setTransform(502.8838,44.225);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_16_1, new cjs.Rectangle(0,0,1005.9,88.5), null);


(lib.Path_15 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#A6B4B7","#A6B4B7"],[0,0.945],-442,0,442.1,0).s().p("EhFEgA6MApigBsMBgnAB+Mg+uADPg");
	this.shape.setTransform(442.075,16.725);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_15, new cjs.Rectangle(0,0,884.2,33.5), null);


(lib.Path_14_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#C3D3D6").s().p("A/ZxfMA+zgCMMAAUAkPMg/bADIg");
	this.shape_1.setTransform(203,125.975);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_14_1, new cjs.Rectangle(0,0,406,252), null);


(lib.Path_9_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFD9BE").s().p("ApUBaIDLgHQDOgKASgJQAJgFByhXQBwhWAngSQASgIAigZQAkgcARgJQA/ghAqBGQAqBHAhBGQAQAiAHAVIAzAXQA0AdAJAhQAKAhA1AgQAaAQAZAJIz9AIg");
	this.shape_1.setTransform(63.9,21.4464);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_9_1, new cjs.Rectangle(0,0.1,127.8,42.699999999999996), null);


(lib.Path_0 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#524655").s().p("AAYJ9QhVgDhJgOIg3gOQg8isgzjyQhoniAolbQA3DyBaD2QC1HtCuAcQCfAZA4g6QAMgMAHgNIAGgmQACAUgIASQgtD9gPAaQgNAXhHAMQg9AKhZAAIg0gBg");
	this.shape.setTransform(37.5985,63.7633);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_0, new cjs.Rectangle(0,0,75.3,127.6), null);


(lib.Path_7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#524655").s().p("AmQAeQimgMAAgSQAAgQCmgMQCngNDpAAQDrAAClANQCnAMAAAQQAAASinAMQilAMjrAAQjqAAimgMg");
	this.shape_2.setTransform(56.65,4.175);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_7, new cjs.Rectangle(0,0,113.3,8.4), null);


(lib.Path_10 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#59534F").s().p("AgvC8QBVgQCngkQivAhiyAOQi/APirgKQAugMCmgSQCKgPBFgfQhSgFh3AMIAwgJQiOgDjrAQQhkAKhwAGIgmADQm2Amk0gBQBtgQCwgHICigFQjFACiugJQAlgGE7gfQDcgVB8gmQiSgBkfAOQkgAOiPAAQA/gCC/gXQCAgPBWgDQkMADiQAAQkbAAi+gWQBygUDeAIQEAALBZgIQhmgIiMgBIj0ACQC2ghESAGQhMgNhvgIQhogGhaABQCnggEDgBQCUgBEfAHQiTghkjAIQlCAQiDAAQDTgeE1gMQCxgGFcgHIgogHIFGAAQBtACA5gCQCDgCA9gOQjPgPh1gXQB5ACEHgIQDqgCCOAbQBWAFDCgIQDUgIAzABQhHAGhkAGQCbAhFPgTQDSgMAzgCQCQgFBiALIirAVQhoAMhDACQBSANCFgKQCkgNA0ACQgwABhkANQhhAMg0ABQBTABCggKQCjgKBPABIi1AYQhBAJgzAFQBKgEBngBIC2gDQgqADgvABIhhABICUADQCIAEBWgIQjzAwijAIQA2ANBkgGIChgJQg4ADiAAWQhmAShDACQBOAAB/gMIBdgIQBMgKA2ADQgtAAhVAHQhCAJhSATQi8AphVABQA9gICPgbIjEAdIg6AIQhQAShcAOQhwAQhlAFQBjgBAqABQBOACA9AGQgtAEifAjQgoAJgjAFIARABQmBAtgdACQkQAXicgbQBPADBXgJQBVgJBJgSIjdASQiKAMhTgHQB9gOB7gdQhlAGkNAjQi1AYh7AFQBWgGBugVgApwCbQA9gDDNgaIBCgHIiLAYQhZAMhIAAIggAAg");
	this.shape_3.setTransform(212.675,21.468);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_10, new cjs.Rectangle(0,0,425.4,43), null);


(lib.Path_1_0 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#59534F").s().p("As9oAQABgdAIgjQAPhIAdglQAagiAqgDQA4gEAXgNQAmgUBSgNQAogFAhgCIDpBXIB3gvICABDIDvAAIHGhKIAMAAQAPACAMAMQAoAjADBwQAFCzAGORIgij+IgtiQQguiZgJg3QgHg2gVAcIgSAoIguh/IAGhkIgvAvQhdiTgUgbQgNgQAJg2IAKgyIhWAvQgugTg5gSQhvglguABQg2AAglAyQgkAwgZBlQgTBLgXCjQgYCngHAiQgSBLgYBLQgdBXgXAlQgiA1hPCnIhkCmQgMh0gLiEQgWkKAEhPQAFhPA6gsQAcgVAagHIhuAZIAHifIB4hXIh/AhIAAinIgHhCIhQB4IgMBhQgOBjAAARQAAARghgOIghgQIAnBDIgnCzIhRgvIANAnQAMAqgFAMQgFASgRBFQgRBJAAANQgBAQgoC4QgNA9giC6g");
	this.shape.setTransform(83,78);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_1_0, new cjs.Rectangle(0,0,166,156), null);


(lib.Path_1_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#59534F").s().p("A2XGTQE5iHClg0QCkgzC2guQBagWA6gNQpRAyjWAQIgqADQgkAPgmAVQg1AchIATQgtALhYAPIofBbIE/iKIiSABQhWABg9gEQDQiIGchFQFig6F8AHIAOgDQnPAAokAEQxFAJmfAWQKWhGKxhQIBzgOQk1gGk5AbQAxgnBMgQQAwgLBcgGINkg4QgDAWAbAIQAYAHAbgGQBFgOBQgNIAOAPQBfgOBOgQQAmgIAVgIQh1AKiBAVQgvgxg9giQhrg8h7AmQhEAYglALQhCATg4AAQAHhUExgzQChgbDxgYQAvgIAZACQAUABAYAIIArAQID2BmQB5gCA3gMQAygLAxAMQAhAJA3AdQBEAiAeAMQA9AYBBAGQDFAQE5AAQhOgYhhgXQjCgthcAKQhIAIDKgnQEIgzAzgRQBighFJAAQBCAAFJgQQiDAph6ApQjyBSAzAAQAtAACrAQQgDgPADgPQDNh9DqguQhAARgsA4QgsA2gJBEQB8gBCsAIIVWBSIBjCEICUAQItoDVIzTghIgHAOQgIAQADAQQAIAxBnAVQBnAUDeAAQBvAABagEQi4ARjfAOQm8Adi6gKQi5gLiUgMIhvgKQgIAQgXAXQgtAthIAfQhIAfFmAUQCzALDBAEQr1AxjVARQiFAKiYgMIh+gPICMhGQCchKBTgVQBRgUgQhCQgFgVgOgWIgOgTQhJAuhiAvQjBBehxALQg/AGjKgKQiagIhLAcQhSAfkYBGIkHBAg");
	this.shape_2.setTransform(330.9,52.875);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_1_2, new cjs.Rectangle(0,0,661.8,105.8), null);


(lib.Path_0_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#59534F").s().p("AmNSoQgMgMgPgdQgcg6gLhSQgKhSAlwuQASoWAVoHIAhhzIMPBFMAAvAmpIgIBNg");
	this.shape_1.setTransform(46.6089,131);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_0_1, new cjs.Rectangle(0,0,93.2,262), null);


(lib.Path_11 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.CachedBmp_22();
	this.instance.setTransform(-1.25,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_11, new cjs.Rectangle(-1.2,0,26,2.5), null);


(lib.ventana = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("ARTc/Mgq/gAKIIKgOIXDgJIAAgLIHjABIgdgFIAAAAQgSgCgOAEIAAAAQAFgOAOgJIAAAAQAJgFAJgBIAAAAQgJgEgKgNIAAAAQgNgRgKgDIAAAAIgPgBIAAAAQgKAAgFgEIAAAAQANAhAaAYIAAAAQgUgJgWgYIAAAAQgGgFgCgBIAAAAIgJgCIAAAAIAAACIAAAAQgBAPgHAMIAAAAQAAgJgEgJIAAAAQAEAJAAAJIAAAAQABAIgCAIIAAAAQgjgDgjALIAAAAIAEgMQgGgGgIgCIAAAAQgIgBgHACIAAAAQAEgFABgGIAAAAQgMgDgNACIAAAAQgMADgJAHIAAAAQgEgDACgFIAAAAQABgFAGgDIAAAAIAJgEIAAAAQAGgCABgEIAAAAQgNgFgMgKIAAAAQAMAEANgCIAAAAQAOgBALgIIAAAAQAFgDgBgKIAAAAIgBgCIAAAAIgHAAIAAAAIgVABQADAEAFACIAAAAQgSgEgTAFIAAAAQgTAFgPAMIAAAAIgIAtQgNgTgLgKIAAAAQgQgNgRABIAAAAQgKABgNAIIAAAAIgWAQIAAAAQgNAIgNABIAAAAQgOABgIgJIAAAAIAogUQgHABgBgLIAAAAQABgKAGgIIAAAAIgTADQAIgJgBgMIAAAAQgLADgNgBIAAAAQgKgBgIgEIAAAAIADgBIAAAAQAEgDABgEIAAAAQgBgHgKgHIAAAAIAdgNQgVgWgagLIAAAAQAPgQAWgFIAAAAQAWgGAVAIIAAAAIgDgdIAZAHIABgVIAVADIgEADIAAAAIAEgDIAAAAIAHgGIAAAAQALgJAGgLIAAAAIAJgKIgJAKQgGALgLAJIAAAAIgGgJIAAAAQgIgMgBgNIAAAAIhKALIANgeIAogDQgHgFgDgKIAAAAQgCgIADgHIAAAAQgPAGgOAKIAAAAQATgPAXgNIAAAAIgWAEQATgKATgHIAAAAQAhgNAlgEIAAAAQglAEghANIAAAAIgGgFIAAAAQgHgHAAgKIAAAAQAAgLAHgEIAAAAQAIgFALAEIAAAAQAHACANAGIAAAAQAKAFALgFIAAAAQAMgFgEgJIAAAAIgeAJIAZg3IgVAOIgBgGIAAAAIABAGIAAAAIAAAAIAAAAIgPAJQAEgDAAgIIAAAAIgLgBIAAAAIgFABIAAAAIAQgHIAAAAIALgGIAAAAIgLAGIAAAAIAAgOQgKgGgNgCIAAAAIgPgBIAAAAIAkgJIgYgaQAPAEAPAIIAAAAIgHgIQgPgEgJgMIAAAAIAHgGIAAAAIgCgCIACACIAAAAQAQALAUAHIAAAAQgUgHgQgLIAAAAQAPgMARgHIAAAAQAWgJAYAAIAAAAQAOABAGgCIAAAAQAJgBAEgGIAAAAIgLgBIAAAAQgVgCgMAEIAAAAIAcgOIgOgGQAaAAAVgQIAAAAIAGACIAAAAQAyASAAAdIAAAAIAKgIIACAHIAAAAIgCgHIAAAAIgKAIQAAgdgygSIAAAAIAQgCIAAAAQAcgBAGgLIAAAAQADgIgKgDIAAAAQgKgEgKAEIAAAAIhRAaQATgbAfgSIAAAAQAegRAhgDIAAAAQALgBAHgEIAAAAQAKgFgDgIIAAAAQgJAPgTACIAAAAQgUACgLgNIAAAAQAJgFgBgMIAAAAQAAgLgGgHIAAAAQgHgHgKgEIAAAAQgHgDgNgDIAAAAIBKACQADgNAIgKIAAAAQAGgGAGgEIAAAAQgIgGgFgGIAAAAIAegBQgIgQgSgFIAAAAQAXgRATgXIAAAAIATARQAAgMAMgGIAAAAQANgGAJAIIAAAAQAFgMgIgMIAAAAQgHgMgNgBIAAAAIBEg4QACAOALAKIAAAAQAMALAOAAIAAAAQAIgQgIgTIAAAAQgHgTgRgIIAAAAIAhAJQAJgLARgBIAAAAQAJgBAXADIAAAAQARACAOgGIAAAAQAQgGABgOIAAAAQgHAKgQAAIAAAAQgNAAgKgKIAAAAQgJgJgDgOIAAAAQgCgMACgOIAAAAQAagHAaAGIAAAAQAcAHATARIAAAAIgSgZQANgGAHgMIAAAAQAHgNgCgOIAAAAQgCgNgKgKIAAAAQgJgJgOgDIAAAAQAYgBAjAtIAAAAQAQAVAHAGIAAAAQAMAKAKgGIAAAAQgGgQgJgTIAAAAQASgCAOgFIAAAAMgAHggFMgsEAJIIALbnIAsgOIAyAOIAAhYIANAAIAABcIAUAFIAAI4IAZgDIAAlEIB/gdICJA8IAAgvIAQgDIAAFwIA7AZIAEk9IBZgNIA2AjIAAGNIAwANIAAiMIAygQIAyAWIAABsIAXgQIAAkdIBmgXIBuANIAAD4IAngHIAyATIgCAzIAcgJIAAjuIBPgXIA9ANIAADrIAfAAIgDAdIAggEIAAiIIAWAAIAACIIAjgMIAAh2IAmgJIgDg2IAsgwIAtAwIAACYIAmgDIgDApIAcgDIAAgpQASACABAXIAAAAQABALgEALIAAAAQAOgCAFABIAAAAIAAkAIDbgvIC0BfIAADbIA8AGIAAAVIAAALI3DAJIoKAOIhnACIAAgDIj8gBMgALgozMAw/gKIIglAbIAlgbIMOpJIBZAIMAAPA+XIhdAEgANrcZIAAAAIAAAAIAAAAgANscZQALAAAKgDIAAAAQgKADgLAAgANncZIgBAAIAAAAIABAAgAODcVIABAAIAAAAIgBAAgARLcVIAAgOQgHAHgIAFIAAAAQgdgPghgFIAAAAQgigFghAGIAAAAQAHgUAZgFIAAAAQAVgFAOAMIAAAAIgBgCIAAAAIgJgKIAAAAQgGgFgCgBIAAAAQgDgCgJgBIAAAAQgRgBgQgFIAAAAIgFAGIAAAAQgHAIgJADIAAAAQgKADgGgFIAAAAQAIANgIAQIAAAAQgHAPgOAHIAAAAgAQdcDQgRgQgLgUIAAAAQADgHAHgGIAAAAIADgDIAAAAIgJgBIAAAAQgJAAgFgEIAAAAQAEALAGAKIAAAAQALAUARAQIAAAAIAAAAgARDb1IgDgEIAAAAIgDgEIAAAAIgCgFIAAAAIACAFIAAAAIADAEIAAAAIADAEIAAAAIAAAAgAMxb1IgBgBIAAAAIAHAAIAAAAQgHgDgEgHIAAAAIgCgGIAAAAIgBAEIAAAAIABAFIAAAAIAEAEIAAAAIACADIAAAAIABABIAAAAIAAAAgALIbeIAAADIAAAAIAAgDIAAAAIgCgGIAAAAIACAGgARKbgIAAgPIAAAPgAKYbeIAMgPIAAAAIgMAPIAAAAQgEgOgBgJIAAAAQABAJAEAOgAMpaaIgDADIAAAAIgDAEIAAAAQgJANARAVIAAAAQAKALAGAGIAAAAIAIAFIAAAAQAFADAGABIAAAAQgGgBgFgDIAAAAIAvgEQgIgOgNgKIAAAAIgmADQAPgDARgEIAAAAIAdgIIAAAAIgdAIIAAAAQgNgIgPgEIAAAAIgBAAIgMgEIAAAAIARABIAAAAIABgBIAAAAQABgEgDgDIAAAAQgCgEgJgDIAAAAIgJgEIAAAAIgBADgAP0bVQgNgLgIgPIAAAAIANAAQABgEgHgHIAAAAIgTgNQgBAMgFAMIAAAAIgGANIAAAAQgYgFgKgIIAAAAIgUgQIAAAAQgMgLgKgCIAAAAQAKACAMALIAAAAIAUAQIAAAAQAKAIAYAFIAAAAIAFABIAAAAQAcAGAMAGIAAAAIAAAAgALhbVQgNgLgIgPIAAAAIANAAIAAgCIAAAAIgMAAIAAAAIgDADQAEAJACAJIAAAAIgSgEIAAAAIASAEIAAAAQALAEAGADIAAAAIAAAAgAQ/bDIALAOIAAAAIgLgOIAAAAQgMgOAAgLIAAAAQAAALAMAOgARBbQQgOgMgSgEIAAAAIgEgBIAAAAIAEABIAAAAQASAEAOAMIAAAAIAAAAgAMvbQQgLgMgJgOIAAAAIgmgPIAAABIAAAAIgMgSIAMASIAJAOQAFAGADABIAAAAIAIADIAAAAQASAEAPAMIAAAAIAAAAgAKTa8QAKAGASAEIAAAAQAQgNAUgIIAAAAQgUAIgQANIAAAAQgSgEgKgGIAAAAIAAAAgAL/bCIgLgYIAAAAQgCAHgGADIAAAAQgfgWgjgMIAAAAQAjAMAfAWIAAAAIAQAMIAAAAIADACIAAAAIAAAAgAJRa2QgXAGgWAEIAAAAQAWgEAXgGIAAAAIARgFIAAAAIgSABIAAAAIABAEgAOSa8IgCAAIAAAAIACAAgAN8a7IAJAAIAAAAIgJAAgAOGa7IgBAAIAAAAIABAAgAH4azIAAAAIAAAAIAAAAgAH5azIACgBIAAAAIgCABgAOEayQgOgDgSgCIAAAAQgFgFgDgHIAAAAIAAgBIAAAAIAAADIAAAAIADAGIABADIAAAAIAEABIAAAAQASACAOADIAAAAgANiayIAAAAIAAAAIAAAAgANiayIARgBIAAAAIgRABgAJvayIAAgCIAAAAIgDgDIACgCIAAAAIAAgBIAAAAIAAgFIAAAAIgGgHIAAAAIAHACIAAAAQADgIAMACIAAAAIAIACIAAAAIgIgCIAAAAIgEgCIAAAAQgIgCgKACIAAAAQgHABgMAEIAAAAQgGAGAAAKIAAAAIgIgBIAAAAIgrgDIAAAAIArADIAAAAIAIABIAAAAQATABANAEIAAAAIAAAAgAJQayQgaAAgagIIAAAAQAaAIAaAAgAH1axIgBAAIAAAAIABAAgAH+axIAAgBIAAAAIAAABgAMBaaQAOAIAJAMIAAAAIAAgBIAAAAQAAgDADgFIAAAAIAKgRQgNgIgRgPIAAAAIgKATIABgMIAAAAIAAgGIAAAAIACgJIAAAAQAAgCgHgGIAAAAIgFACIAKAPIAAAGIAAAAIgkANIAEAAIAAAAQASAAARAJgAM9auIgCgBIAAAAIACABgAN/atIABgBIAAAAIgBABgAQualQgDAFAAACIAAAAQAAgCADgFIAAAAIALgUQABABAAAAQABAAAAABQAAAAABABQAAAAAAABIAAAAIAAACIAAAAIAAgCIAAAAQAAgBAAAAQgBgBAAAAQAAgBgBAAQAAAAgBgBIAAAAgAOAasQACgDAEAAIAAAAQgEAAgCADgAOIapIAAAAgAOHapIAAAAIAAAAIAAAAgAOGapIAAAAIAAAAIAAAAgAHxanQAAgRAJgQIAAAAQgJAQAAARgAHiZ4QgFACgDAFIAAAAQgNARgFAUIAAAAQAFgUANgRIAAAAQADgFAFgCIAAAAIAAAAIAAAAIAAAAgAPxaSQAGACAFADIAAAAIAAAAQAIAEAFAIIAAAAQAGgXAAgWIAAAAQAAAWgGAXIAAAAQgFgIgIgEIAAAAIAAAAQgFgDgGgCIAAAAIAAAAgAJIaiIAIgLgAPUabIAAgEIAAAAIAAAAIAAAAIAAAAIAAAAIAAAEIAAAAIgYgJIAAAAIAYAJgANoaaIAAAAIAAAAIAAAAgANoaaQAEAAAFgFIAAAAQgFAFgEAAgANnaaIgGgBIAAAAIAGABgANhaZIAAAAIAAAAIAAAAgANSaYIgFgHQAFAAAFgEIAAAAIglg2IgCADIAAAAIgGgNIgEgHIADABIAAAAIAIAGIAAAAIgIgGIAAAAIgBgBQgIgCgGgDIAAAAQgJAFgIAHIAAAAIgBABIAAAAIAAAAIAAAAIgHAHIAAAAQAGABAEAEIAAAAQAEAEABAGIAAAAIgMAFQgDgCgJAAIAAAAQgGAAgEgBIAAAAQAEABAGAAIAAAAQAJAAADACIAAAAQAFACAGAFIAAAAIANAIIAAAAIAbAPIAAAAQAQAIALAJIAAAAgAPVaWIAAAAIAAAAIAAAAgAPVaWQAIgFAKAAIAAAAQgKAAgIAFgANyaUIABgBIAAAAIgBABgAPwaSIgBAAIAAAAIABAAgAIvaSIgBgJIAAAAIABAJgAPnaRIAAAAIAAAAIAAAAgANiaQIgDgUIAOASQAAgFACgDIAAAAQACgEADABIAAAAIABAAIAAAAIADACIAAAAIAAADIAAAAIAAgDIAAAAIgDgCIAAAAQgBgFgFgFIAAAAQgHgIgKgBIAAAAIAEgCQgJgBgKACIAAAAQAGgPAAgIIAAAAQgBgHgFgEIAAAAQgFgFgGABIAAAAIgBAPQgEgBgEACIAAAAIACADIAAAAQADAGAFALIAAAAQAFAJAJAKIAAAAIAPAQIAAAAgAJ9aJQgBADgCACIAAAAQACgCABgDIAAAAIAAgCIAAAAIAAACgAKsaGQAAgPgJgMIAAAAQAJAMAAAPgAKSZ5IgBAAIAAAAIABAAgAKSZ5IACAAIAAAAIgCAAgAJbZxQAUAAAQAEIAAAAIALADIAGABIAAAAIgGgBIAAAAIgLgDQgQgEgUAAIAAAAQgMgBgZACIAAAAQgDgPAAgOIAAAAQgLARgTAKIAAAAQgQAIgSAAIAAAAQASAAAQgIIAAAAQATgKALgRIAAAAQAAAOADAPIAAAAIAegBIAAAAIAHAAgAKfZ0QgEAEgGABIAAAAQAGgBAEgEIAAAAQAFgDAAgFIAAAAQAAAFgFADgAHiZ4IAGgBIAAAAIgGABgAHzZ4IAAAAIAAAAIAAAAgAHvZ4IAAAAgAHtZ4IgFgBIAAAAIAFABgANrZYIAFAKIACAEIACAEIgCgEIACgCIgEgCIAAAAIgFgKIAAAAgAKvZfQAFgQAOgJIAAAAQgOAJgFAQgAQ/ZVIAAgGIAAAAIAAAGgARAZQIgBgHIAAAAIgBgPIAAAAIAAgBIgCAEIAAAAQgCADACADIAAAAIADAGIAAAAIABAHIAAAAIAAAAgAMIZOIgCgBIAAAAIACABgAQUZEQgGADgDAGIAAAAQADgGAGgDIAAAAQAEgDAFgBIAAAAQgFABgEADgAHaZMIAMgVgAMxZMIABgGIAAAAIgBAGgALxZLIAFAAIAAAAIgFAAgAL2ZLIAAAAIAAAAIAAAAgAIRYwQgFALAAAMIAAAAQAAgMAFgLIAAAAQAFgNAIgJIAAAAQgIAJgFANgAMuZGIgBAAIAAAAIABAAgAMuZGIACAAIAAAAIgCAAgAMwZGIACAAIAAAAIgCAAgAMpZGIgBAAIAAAAIABAAgAHdYxQgKAFAAAMIAAAAQAAgMAKgFIAAAAIAAgBIgBAAIAAAAgAImY+IABgZgARIY6IAAAAIAAAAIAAAAgARHY6IAAAAIAAAAIAAAAgARKY6IAAgPIAAAPgAJWY5QgBgSgEgSIAAAAQAEASABASIAAAAIAAAAgAQxY3IgEgHQAGABAEgEIAAAAIgqg9QgDAIgBAIIAAAAQgQgHgSADIAAAAQgNADgKAHIAAAAIgCgBIAAAAIACABIAAAAQADABAFAAIAAAAQAJAAADABIAAAAIAMAHIAAAAIALAIIAAAAIAcAPIAAAAQAQAJAKAIIAAAAgALZYrQgDADgKABIAAAAIgjABIAjgBQAKgBADgDIAAAAQADgCAAgEIAAAAQAAAEgDACgARCYwIgFgFIAAAAIgFhZQgSACgNANIAAAAQgGAFgDAGIAAAAIgKgGIAAAAIAKAGIAAAAQAIAGAFAKIAAAAIAIARIAAAAQAEAJAJAKIAAAAIALALIAAAAIAFAFIAAAAgARKYrIgLgPgAN0YbQAEADAAAGIAAAAIAAAHIAAAAIAAgHIAAAAQAAgGgEgDIAAAAIAAgBIAAAAIAAABgAIzYqQAAgGACgGIAAAAQgCAGAAAGgAPJYNIAVAMIgBAQIAAAAIABgQIAAAAIABgEIAAAAQABgDgQgMIAAAAIgHAHgAJbYXIAAANIAAAAIAAgNIAAAAIgBgBIAAAAIABABgAPuYiIgHgGIAAAAIgBACgALiYNQgBANgJAGIAAAAQAJgGABgNIAAAAIABgDIAAAAIgBADgANuYZIACgBIAAAAIgCABIAAAAIAAgHIAAAAIAAAHgANIYZIgBgGIAAAAQgGgEgJgBIAAAAQgOgCgLAFIAAAAIggADIAAAAIgigaIAiAaIAggDIAAAAIAIgBIAAAAQAhgBAAAKIAAAAIAAAAgANxYYIgBAAIAAAAIABAAgAJpYLIAAAAIAAAAIAAAAgAJ5YHIAAAAIAAAAIAAAAgAJ5YHIAHAAIAAAAIgHAAgAJNX9IAoAKIACAAIAAAAIgCAAIAAAAIgogKIAAAAgAM/YHIAAgBIAAAAIAAABgAKGYGQAOgCAMgIIAAAAQgMAIgOACgAJqYFIABABIAAAAIgBgBIAAAAIgCAAIAAAAIACAAgAMgYAIAAAAIAAAAIAAAAgAMgYAIgBAAIAAAAIABAAgAMuX/IAAAAIAAAAIAAAAgAMvX/IgBAAIAAAAIABAAgAHfX7IgTADIAAAAIATgDIAAAAQAKgDAGgFIAAAAQgGAFgKADgAMRX9IgCAAIAAAAIACAAgAOGX8IAAAAIAAAAIAAAAgALdX6IASgCIAAAAIgSACgAN8X5IACAAIAAAAIgCAAgAN+X5IABAAIAAAAIgBAAgAOAX5IgBAAIAAAAIABAAgALvX4IAAAAIAAAAIAAAAgAOUX0IgBgLIgFAHQgHgFgMgBIAAAAIgfAAIAAAAQgZgBgUgUIAAAAIgFgFIAAAAIAFAFIAAAAQAUAUAZABIAAAAIAfAAIAAAAQAMABAHAFIAAAAIAFgHIABALgALwX0IgigDIAAAAQgUgCgOgFIAAAAQgRgGgNgLIAAAAIgBgBIAAAAIABABIAAAAQANALARAGIAAAAQAOAFAUACIAAAAIAiADIAAAAIAAAAgAHaXrIgFAFIAAAAIAFgFIAAAAQALgNALgKIAAAAQgLAKgLANgAJWXvIgBAAIAAAAIABAAgAJWXvIADAAIAAAAIgDAAgAJbXuIACAAIAAAAIgCAAgAJLXtIgBAAIAAAAIABAAgAJJXsQgKgEgHgJIAAAAQAHAJAKAEgAL5XqIAAAAIAAAAIAAAAgAL6XqQAJAAAKgEIAAAAQgKAEgJAAgALZXcQAMALAMACIAAAAQgMgCgMgLIAAAAQgGgGgHgKIAAAAQAHAKAGAGgAPaXnIASgzgAMNXmIACgBIAAAAIgCABgAMPXlQAMgFAQgMIAAAAQgQAMgMAFgAJFXjIgCgBIAAAAIACABIAAAAIAAAAgAHOXbIAAAAIAAAAIAAAAgAHOXbQARgBARgFIAAAAQgRAFgRABgAHBXaIACgBIAAAAIAYgLIAAAAIATgHIAAAAIgTAHIAAAAIAEgHIAAAAQgUAAgUAGIAAAAIgLAEIAAAAQAJAJAOgBIAAAAIgCABgAKNXYQgJgOgLgMIAAAAQALAMAJAOIAAAAIAAAAgAILXUIAAAAgAINXUIACAAIAAAAIgCAAgAIQXUIgBAAIAAAAIABAAgAMqXQQgGgTgKgVIAAAAQAKAVAGATIAAAAIAAAAgALKXMIAAAAIAAAAIAAAAgALKXMIABAAIAAAAIgBAAgAPQXJIAWgZgAHuXHIgBAAIAAAAIABAAgAHhXHIABAAIAAAAIgBAAgAHjXHIgBAAIAAAAIABAAgAK6XEIAAgBIAAAAIAAABgAI0W+QAIABAGAFIAAAAQgGgFgIgBIAAAAIgCAAIAAAAIACAAgAImXAIABgBIAAAAIgBABIAAAAgAIoW/QAEgBAFAAIAAAAQgFAAgEABgAIxW+IAAAAIAAAAIAAAAgAQAW0QABAFAEAEIAAAAQgEgEgBgFIAAAAIgBgEIAAAAIABAEgAKHW5IgBAAIAAAAIABAAgAKHW5QAHAAAHgDIAAAAQgHADgHAAgAJ9W4IAAAAIAAAAIAAAAgAKEW3IAUgCIAAAAIgUACIAAAAIgKAAIAAAAIAKAAgAJ6W3QgNgEgJgLIAAAAQAJALANAEIAAAAIAAAAgAKWW2IACgBIAAAAIgCABgAPIW1IAAAAIAAAAIAAAAgAPJW1QAMAAANgEIAAAAQgNAEgMAAgAO8W0QANgCALgKIAAAAQgLAKgNACgARHW0IgGgvIgBADIAAAAQgCAEgDABIAAAAQgDgKAAgJIAAAAQAAAJADAKIAAAAQADgBACgEIAAAAIABgDIAAAAIAGAvgAJ4WyQgHgEgDgHIAAAAQgDgFAAgHIAAAAQAAAHADAFIAAAAQADAHAHAEIAAAAIAAAAgAPiWxIABAAIAAAAIgBAAgAPkWxIACgBIAAAAIgCABgAN8WwIAugcgAJAWuIgBAAIAAAAIABAAgAJAWuIAKAAIAAAAIgKAAgAJLWuIAAgBIAAAAIAAABgAJMWtIAAAAgAH5WqIAAAAgAH8WoQALgGAOAAIAAAAQgOAAgLAGgAI3WoQgTgFgMgBIAAAAIgCAAIAAAAIACAAIAAAAQAMABATAFIAAAAIAAAAgAOsWmIALgGIAAAAIgLAGgAOtWmIAOgBIAAAAIgOABgAIhWmIAAgBIAAAAIAAABgAO7WlIAAAAIAAAAIAAAAgAIVWiIAAAAIAAAAIAAAAgAQIWiIAGgBIAAAAIgGABgAQSWhIAAAAIAAAAIAAAAgAQQWhIAAAAIAAAAIAAAAgAQPWhIAAAAIAAAAIAAAAgAQmWfIgBgCIAAAAIABACgAJ8WfIgBAAIAAAAIABAAgAJ+WfIAFgBIAAAAIgFABgAJ4WfIAAAAIAAAAIAAAAgAJyV2IATAoIgTgoIAAAAgAMzWcQAtgaA1gEIAAAAQg1AEgtAagAJQWTQAAgSAUgXIAAAAQgUAXAAASgAP9WRQARgKAMgRIAAAAQgMARgRAKIAAAAgANzWRIATgFgAJFWQQgHgMgHgPIAAAAQgFgNAAgJIAAAAQAAAJAFANIAAAAQAHAPAHAMIAAAAIAAAAgANUWPIACAAIAAAAIgCAAgANYWOQAPgDAPAAIAAAAQgPAAgPADgAOGWMIgBAAIAAAAIABAAgAN3WLIgBAAIAAAAIABAAgAQUWJQARgEAKgIIAAAAQAHgFACgFIAAAAQgCAFgHAFIAAAAQgKAIgRAEIAAAAgALGVxQADAJABAGIAAAAQgBgGgDgJIAAAAQgCgEAAgEIAAAAQAAAEACAEgAQFV+IgBgBIAAAAIABABgAOVV+IgCgBIAAAAIACABgAOTV9IgCAAIAAAAIACAAgANNV8IABgBIAAAAIgBABIAAAAQAlgKAlgFIAAAAQglAFglAKgANQV7QAOgDAPAAIAAAAQgPAAgOADgANtV4IAAAAIAAAAIAAAAgAP3V4IABAAIAAAAIgBAAIAAAAIAAAAgAPeV4IgdgHIAdAHIAAAAgAP6V4IgBAAIAAAAIABAAgAP5V4IAAAAIAAAAIAAAAgAPKV1IgkgDQgEAAgCgCIAAAAQAAAAgBgBQAAAAAAgBQAAAAgBgBQAAgBAAAAIAAAAQAAAAAAABQABABAAAAQAAABAAAAQABABAAAAIAAAAQACACAEAAIAAAAIAkADgAKYVzIAAgBIAAAAIAAABgAKYVyQAAAAABgBQAAAAABgBQAAAAABAAQABAAAAAAIAAAAQAAAAgBAAQgBAAAAAAQgBABAAAAQgBABAAAAgAKXVyIAAgBIAAAAIAAABgAKiVyIgBgBIAAAAIABABgAKgVxIgBgBIAAAAIABABgAKdVwIgBAAIAAAAIABAAgAKFVoIACAAIAAAAIgCAAgAKHVoIAAAAIAAAAIAAAAgAOGVmIgkgIIAkAIIAAAAgALEVSQACAHAFAEIAAAAQgFgEgCgHIAAAAIgBgFIAAAAIABAFgAJUVbIASgHgAIXVYIgBAAIAAAAIABAAgAOGVYQgWgHgRgLIAAAAQARALAWAHIAAAAgAIMVXIACgBIAAAAIgCABgAIPVWIgBAAIAAAAIABAAgAOVVTQgQgMgOgPIAAAAQAOAPAQAMIAAAAIAAAAgAOHVTIgJgFIAAAAIAJAFIAAAAgAPKVRQgLAAgHgGIAAAAQAHAGALAAIAAAAgAOhU9QACAJAAAIIAAAAQAAgIgCgJIAAAAQgEgVgNgQIAAAAQANAQAEAVgAJOVOIAOgCgAPmVIIg1gHIA1AHgAJFVIIAJgCIAAAAIgJACgAJOVGIAAAAIAAAAIAAAAgAOIU/IgCAAIAAAAIACAAgAOIU/IAEAAIAAAAIgEAAgAOEU/IgDgBIAAAAIADABgAONU+IAAAAgALdU8QgGgMgKgIIAAAAQAKAIAGAMIAAAAIAAAAgAQCUzQANAAANAHIAAAAQgNgHgNAAIAAAAgAIVU5IgBAAIAAAAIABAAgAIVU5QAJAAAJgDIAAAAQgJADgJAAgAHzUrIACACIAAAAIACABIAAAAQALAJAMABIAAAAIAAAAIAAAAIAAAAIAAAAQgMgBgLgJIAAAAIAIgGIAAAAIgKAFIAAAAIgCgCIAAAAIgWgWIAAAAIAWAWgAKgU2QABgUAOgOIAAAAIAAgDIAAAAIAAADIAAAAQgOAOgBAUIAAAAIgqgigAJRUZIgNALIAAAAQgLALgOAFIAAAAIgEACIAAAAIAEgCIAAAAQAOgFALgLIAAAAIANgLIAAAAIAAAAgAPpU1QgRAAgNgMIAAAAQANAMARAAIAAAAgAOYUtQgsgOgwAAIAAAAQAwAAAsAOIAAAAgALQUpIAAAAIAAAAIAAAAgALRUpQAJgBAHgIIAAAAQgHAIgJABgAQBUVQABAEAEAEIAAAAQADADAEABIAAAAQgEgBgDgDIAAAAQgEgEgBgEIAAAAgALiUfIAAAAIAAAAIAAAAgAPnUaQgRgBgPgHIAAAAQAPAHARABIAAAAIAAAAgAJTUYQAEgCAFAAIAAAAQgFAAgEACgAJgUWIAAAAgAJeUWIAAAAIAAAAIAAAAgAJdUWIAAAAIAAAAIAAAAgAJ7UUIAAAAIAAAAIAAAAgAJ8UUQAHAAAGgGIAAAAQgGAGgHAAgAJ2UUIAAAAIAAAAIAAAAgAQZULIAJAGIgJgGIAAAAgALVT4QAMAIADAGIAAAAQADAFAAAFIAAAAQAAgFgDgFIAAAAQgDgGgMgIIAAAAQgLgHgDgFIAAAAQADAFALAHgAO3UPIASgCgAO4UPIACAAIAAAAIgCAAgAO7UPIgBAAIAAAAIABAAgAOjUOIA8gMgAJYUEQgKABgHAHIAAAAQAHgHAKgBIAAAAIAEgRgAQZULIADAAIAAAAIgDAAgAQeUKQAKgBAKAAIAAAAQgKAAgKABgAQ6UJQgEgJAAgLIAAAAQAAALAEAJIAAAAIAAAAgAQ6UJIgDAAIAAAAIADAAgAQzUJIAAAAIAAAAIAAAAgAKrUHIgBAAIAAAAIABAAgAKrUHQAJAAAIgCIAAAAQgIACgJAAgAKpUHIgBAAIAAAAIABAAgAK9UFIABAAIAAAAIgBAAgAPfUCIgBAAIAAAAIABAAgAPSUBIAAAAgAPSUBIAEgBIAAAAIgEABgAPXUAIgBAAIAAAAIABAAgAPZT/QALgCAKAAIAAAAQgKAAgLACgAPyT9IgCAAIAAAAIACAAIAAAAgAPvT9IAAAAIAAAAIAAAAgAQqT3IAHgJIgHAJQgGgHAAgJIAAAAQAAAJAGAHgAJMT1IAAAAIAAAAIAAAAgAJNT1QAKAAAFgCIAAAAQgFACgKAAgAK+T0IgBAAIAAAAIABAAgAK+T0IAFAAIAAAAIgFAAgAI7T0IgBAAIAAAAIABAAgALFT0IABAAIAAAAIgBAAgALHT0IABgDIAAAAIgBADgAKrTzIgCgBIAAAAIACABgAQLTxIABgUIgBAUQgIgLgLgIIAAAAQALAIAIALgAPzTxIAAAAIAAAAIAAAAgAP0TxIANgBIAAAAIgNABgARJTxIAAgMIAAAMgAQCTwIAAAAgAQtTrQgCADgCABIAAAAQACgBACgDIAAAAIAAgDIAAAAIAAADgAPPTrIgEgBIAAAAIAEABgAQeTrIAIgMIgIAMIAAAAgAQZTeQAFAFAAAFIAAAAQAAgFgFgFIAAAAIAAAAgARJTfIgBADIAAAAIABgDIAAAAIAAgTgAQMTdIAFgCIAAAAIgFACgAQSTbIgBAAIAAAAIABAAgAQ/TaQgLgJgQgJIAAAAIgbgOIAAAAIgMgIIAAAAIgNgIIAAAAIgLgBIAAAAQgGAAgEgCIAAAAQAEACAGAAIAAAAIALABIAAAAIANAIIAAAAIAMAIIAAAAIAbAOIAAAAQAQAJALAJIAAAAgAQ7TSIAAAAIAAAAIAAAAgAQ7TSQAEAAADgCIAAAAQgDACgEAAgAQ6TSIgBAAIAAAAIABAAgARETPIAAAAIAAAAIAAAAgAQwSrIACAEIAAAAQAFAJAIAKIAAAAIAKAKIAAAAIgKgKIAAAAQgIgKgFgJIAAAAIgCgEIAAAAIAAAAgAPtS3QgDAKAAAKIAAAAQAAgKADgKIAAAAIAAgBIAAAAIAAABgAQtSyIABgDgAQjSUIAHAKIAAAAIAGAMIAAAAIAQgrIgQArIgGgMIAAAAIgHgKIAAAAgAQjSUQgGgHgKgFIAAAAQAKAFAGAHgAQjSUIAWgZgAQbSAIAAAAIAAAAIAAAAgAQcSAQAMAAAMgDIAAAAQgMADgMAAgAQRSAQAMgDAKgJIAAAAQgKAJgMADgAQ1R9IABgBIAAAAIgBABgAQ4R8IABgBIAAAAIgBABgAPQR7IAvgcgALSRzQAJACAIgDIAAAAQAIgDAGgHIAAAAIgPgWQAMACAGgOIAAAAQAGgPgKgHIAAAAQgKgIgMAJIAAAAQgMAJAEAMIAAAAQgMgBgMgFIAAAAQAQAXAIAcgAQARxQAGgCAFgEIAAAAQgFAEgGACgAQCRxIALgBIAAAAIgLABgAQORwIgBAAIAAAAIABAAgAOCRqQAvgeA3gDIAAAAQg3ADgvAegAPHRcIATgFgAOnRbIACgBIAAAAIgCABgAOpRaQARgEAQAAIAAAAQgQAAgRAEgAPaRXIgBAAIAAAAIABAAgAPMRWIAAAAIAAAAIAAAAgAPmRIIgBAAIAAAAIABAAgAPlQ5QghAFgiAJIAAAAQAPgEAQAAIAAAAQgQAAgPAEIAAAAQAigJAhgFIAAAAIAGgBIAAAAIgJgCIADADgAPCRDIgBAAIAAAAIABAAgAQxRDIgdgHIAdAHIAAAAgAQdRAIgigDIAtgMIgHgJIAAAAIgMgJIAAAAIgBAEIAAAAQgFgJgLgBIAAAAQgIAAgGAEIAAAAQAAAKgDAKIAAAAQgCAIADADIAAAAQABABAFAAIAAAAIABAAIAiADgAPaQxIgjgIIAjAIIAAAAgAPaQjIgIgKIAJAGIAAAAIgQgcQANAPAQAMIAAAAQgIgMgLgJIAAAAIACABIAAAAQAFABAFgBIAAAAQgWgKgXgJIAAAAIgIAHIAAAAQAPgCAKAOIAAAAQAHAKAAAKIAAAAQgNgFgNgIIAAAAQANAIANAFIAAAAIAOAFIAAAAgAPxP7IAEANIAAAAQACALgBAKIAAAAIAMgMQgFgOgMgIIAAAAQgFgNgIgLIAAAAQAIALAFANgAQdQcIgGgEIgBADIAAAAQgGgBgFgEIAAAAQAFAEAGABIAAAAIAHABIAAAAgAQ5QTIgbgeQAOALARAAIAAAAIgigjQAPAIAQAAIAAAAIAAAAIAAAAIAAgBQgWgLgXABIAAAAQAFAKADALIAAAAQAFAQgBAQIAAAAIgVgDIAVADIAgAEgAPtP5IgBgBQgHgEgJgCIAAAAQgJgCgIAAIAAAAQgegGgeAAIAAAAQAeAAAeAGIAAAAQARADARAGIAAAAgAQNPaIgCAAIACAAIAQgCIgRABIABABgAP6PCQAKAJAHAKIAAAAIgVAEIAVgEIAhgGIAHgCIgHACIgDgDIAAAAIgBAAIAAAAIgCAAIAAAAIACgBIAAAAQAOgDAQAAIAAAAQgQAAgOADIAAAAQgPgMgPAAIAAAAQgIAAgIADgAQzPNIgEgBIAAAAIAEABgAQpPLIAAAAIAAAAIAAAAgAQpPLIAAAAIAAAAIAAAAgAQ3PFIgLgCIALACIAAAAgARIO8QgVAAgVgHIAAAAQAVAHAVAAgA57F7QgPAAgLgKIAAAAQAcABAbgJIAAAAIhPABIBTgRIhegEIAAAAQBWgMBRgVIAAAAQgpgFgpAGIAAAAQgLgWgcgCIAAAAQgcgCgOAUIAAAAIAAgZQASgIAVABIAAAAQAUABASAJIAAAAQAEgHgEgKIAAAAQgFgJgKgCIAAAAQgIgCgKADIAAAAQgHABgLAFIAAAAQgBgHgGgGIAAAAQgFgDgFgBIAAAAIABAAIAAAAQADgCAAgDIAAAAQgBgCgDgCIAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQgBAAAAABIAAAAQAKgFAbgEIAAAAQAdgEAMgHIAAAAQALgGARgNIAAAAQAPgJASADIAAAAQAeAEAYAdIAAAAQAEgFgCgHIAAAAQgCgIgGgDIAAAAQAPAIAQAEIAAAAQABgHgEgGIAAAAQgEgGgHgBIAAAAQAEgCAFABIAAAAIAEABIAAAAQgGgDgGgCIAAAAQgLgCgIACIAAAAIAfgMQgHABgJgDIAAAAQgHgCgFgGIAAAAQALgLARgEIAAAAQAQgFAPAFIAAAAQAQAFAMAMIAAAAQALANADAQIAAAAQAEARgJAKIAAAAIgIAHIAAAAIgHAGIAAAAQgEAEAAAGIAAAAQgBAGAFACIAAAAQAJADAKgEIAAAAQALgEAFgJIAAAAQAFAAAEADIAAAAQAFAEABAEIAAAAQAEgLgGgLIAAAAQAPACALAIIAAAAQANAIAEAOIAAAAQAEAOgMAMIAAAAQgLAMgNgFIAAAAQAIAFALACIAAAAIATADIAAAAIB6APQhdgDhcAQIAAAAQA7AIA7ADIAAAAQh+gDh+AGIAAAAQAwgUAzACIAAAAQgcgHgcACIAAAAQgcACgaAJIAAAAIgZALIAAAAIgVAKIAvAGQBkACBoAKIAAAAQiqABi3AKIAAAAQAVgEATAAgAANFdQBzgIB0gDIAAAAQgwAJg3ADIAAAAIgzABIAAAAIhNgCgAFXFeIAsgOQhHAAhIACIAAAAIAXgGIAAAAQgQgKgUgDIAAAAIgMgBIAAAAQAdgEAbgMIAAAAQAogRAfgeIAAAAIgWgIQgDgGAEgFIAAAAQAFgGAGACIAAAAIgTgbQAKgMAPAAIAAAAQgOgMADgVIAAAAQACgUAQgJIAAAAQAQgJATAJIAAAAQALAGAGAJIAAAAIAAgCIAAAAQABgIAFgFIAAAAIAVgEIgKgKIAAAAIgOADIAAAAQAFgUAWgTIAAAAQAXgUASADIAAAAQAQAEANAMIAAAAQANAMAEARIAAAAQAJABAHgEIAAAAQAIgEADgHIAAAAQATACANAQIAAAAQAOAPAAATIAAAAQAKgIANABIAAAAQgBAFABAFIAAAAQACAEADAEIAAAAQACgLgDgLIAAAAQgDgKgIgIIAAAAQAHgDAIABIAAAAQAIABAHAFIAAAAQAEgBACgEIAAAAQACgEgCgDIAAAAQgCgEgEAAIAAAAQgFAAgCADIAAAAQAHgXAdgFIAAAAQAcgFAPAUIAAAAQAIALgCAKIAAAAQgCAFgGADIAAAAQgEACgEgBIAAAAIAcAQQAJgMASACIAAAAQARACAHAOIAAAAQAGAOgKAPIAAAAQgJAOgQAAIAAAAQAKAFALgEIAAAAQALgDAEgKIAAAAQACAIAJADIAAAAQAJACAGgFIAAAAIAIAUIBzAQIjZALIAAAAQgTABgLgDIAAAAQgHgCgNgIIAAAAQgNgIgHgCIAAAAQgMgDgLAHIAAAAQgLAHADAKIAAAAQgOAJgSADIAAAAQgSACgQgFIAAAAIggASQCOAJCSAAIAAAAQhmAOh4AGIAAAAIhXADIAAAAIADABIAAAAQg+ADg5gBIAAAAIB0gDIAAAAQgWgLgYgBIAAAAQAZAAAWgKIAAAAQgLgkgXgOIAAAAQgOgIgRABIAAAAQgQABgKALIAAAAQgEAFgGALIAAAAIgIAPIAAAAQgEAIgJAEIAAAAQgKADgGgFIAAAAIgbAiIgWgEIgpAPQCAAKB9gEIAAAAIiVAQQCmgDCmgQIAAAAQifAkikAAIAAAAIgoAAg");
	mask.setTransform(332.6998,200.2248);

	// Capa_2
	this.instance = new lib.sombra_ventana();
	this.instance.setTransform(271.4,306.95,0.9883,0.9838,0,0,0,344.4,311);
	this.instance.compositeOperation = "multiply";

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Capa_1
	this.instance_1 = new lib.CachedBmp_47();
	this.instance_1.setTransform(179.3,127.95,0.5,0.5);

	this.instance_2 = new lib.Path_8();
	this.instance_2.setTransform(86.85,316.65,0.4383,0.4383,0,0,0,100.6,144);
	this.instance_2.alpha = 0.4102;

	this.instance_3 = new lib.Path_9();
	this.instance_3.setTransform(70.15,192.15,0.4383,0.4383,0,0,0,159.7,201.3);
	this.instance_3.alpha = 0.3398;

	this.instance_4 = new lib.CachedBmp_46();
	this.instance_4.setTransform(0,0,0.5,0.5);

	this.instance_5 = new lib.Path_16();
	this.instance_5.setTransform(288.35,105.35,0.4383,0.4383,0,0,0,362.3,107);
	this.instance_5.alpha = 0.7305;

	this.instance_6 = new lib.CachedBmp_45();
	this.instance_6.setTransform(131.55,58.2,0.5,0.5);

	this.instance_7 = new lib.Path_18();
	this.instance_7.setTransform(500.45,226.2,0.4383,0.4383,0,0,0,121.2,431.3);
	this.instance_7.alpha = 0.2188;

	this.instance_8 = new lib.CachedBmp_44();
	this.instance_8.setTransform(152.55,66.95,0.5,0.5);

	this.instance_9 = new lib.CachedBmp_24();
	this.instance_9.setTransform(160.6,206.6,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ventana, new cjs.Rectangle(0,0,553.6,415.1), null);


(lib.Interpolación2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.Path_1();
	this.instance.setTransform(54.15,-1.05,1,1,0,0,0,46.8,36.5);
	this.instance.alpha = 0.3398;
	this.instance.compositeOperation = "multiply";

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#84E5F7").s().p("ABlFOQhngajNhVIj8hoQhqgjiTAAQiLAAhagzQgcgRgUgSIgOgQIgEhmIA8ArQBNAuBWAQQA/AMCCADQCMAEAnAFQBKALA0APQAaAIAKAFQgFgfABgoQAAhUAbg0QAgg+BrhEQBohEBVgOQBQgNBRAbQBNAaAbAsQAiA3BYBnQBqB8BQA9QA9AvCLA3QB2AvAQAbIgiBUQgdAPhJAPQiRAejcAAQjuAAiogqg");
	this.shape.setTransform(0.025,0.025);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#6CC5CB").s().p("AExCaQgLgEi6gmQjDgog+gIQg6gIhegdIhTgbQgMgTgIgYQgPgwATgXQANgPAqgMQAugNA6gCQCVgHB3BAQBVAuByAUQBSAPA4gDQAvgDAACfQAAARgxAEIgdACQgTAAgJgEg");
	this.shape_1.setTransform(-59.6432,-3.4912);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-100.8,-37.6,201.7,75.30000000000001);


(lib.Interpolación1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EAH3AlsQiPgehWiqIgqhcIAAAOQgNgigXg7IgKgYQgWgsgVgaQgjgtg8ghQgigThOgeQgsgSgfgOQhLgdgSgQQgvgsgGgbQgFgWAFgfQgBgNACgOQAFgnAfhDQAwhlAJgWQAehOAFhJQALiihskeQhlkJixkzQjMlgiUlaQi7mzgfkUIgJhUIAAAKIg9mlQgNgQgOgZQgVgZgPgtQguiIBHjmQAsiRCYg8QB/gyC+ANQCBAIBOAaQB5AoAPBSQAhCyAQCaQAQCTAHAhQARBWAnB4IBHDeQBdE2AkF5QAzIcBiHZQB0IuCHDQQA+BfBICdQAqBcBRC8QCaFYCJB4QDwDSBaBaQiKAHijABIhCAAQkQAAhvgXg");
	mask.setTransform(-12.1923,-3.4092);

	// Capa_2
	this.instance = new lib.sombra();
	this.instance.setTransform(-11.45,-31.7,1.054,1.0623,-0.707,0,0,117.9,257.5);
	this.instance.alpha = 0.5586;
	this.instance.compositeOperation = "multiply";

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Capa_1
	this.instance_1 = new lib.Path();
	this.instance_1.setTransform(-14.4,177.95,1,1,0,0,0,26.7,32);
	this.instance_1.alpha = 0.6406;

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E9C7AA").s().p("AADgOQgUgYgUgtQgohbADhtIAsgpQAtguAJgWQALgYANAVQAMAUAEAmQACAQABBJQABBHAGAwQAFAugLCeQgLCoACAiQAFBQAAAxg");
	this.shape.setTransform(-129.6687,-173.208);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFD9BE").s().p("EAH3AlsQiPgehWiqQgJgRg3h9QgkhTgfgoQgjgtg8ghQgigThOgeQhLgegjgUQg5ghgegtQgfguAIg2QAFgnAfhDQAwhlAJgWQAehOAFhJQALiihskeQhlkJixkzQjMlgiUlaQi7mzgfkUQgcj9gaidIgUhqQglgWgWhEQguiIBHjmQAsiRCYg8QB/gyC+ANQCBAIBOAaQB5AoAPBSQAhCyAQCaQAQCTAHAhQARBWAnB4IBHDeQBdE2AkF5QAzIcBiHZQB0IuCHDQQA+BfBICdQAqBcBRC8QCaFYCJB4QDwDSBaBaQiKAHijABIhCAAQkQAAhvgXg");
	this.shape_1.setTransform(-12.1923,-3.4092);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.instance_1}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-137.5,-246.9,250.6,487);


(lib.Group = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.Path_11();
	this.instance.setTransform(11.7,52.9,1,1,0,0,0,11.7,1.2);
	this.instance.alpha = 0.4219;
	this.instance.compositeOperation = "multiply";

	this.instance_1 = new lib.Path_1_2();
	this.instance_1.setTransform(355.5,52.9,1,1,0,0,0,330.9,52.9);
	this.instance_1.alpha = 0.5898;
	this.instance_1.compositeOperation = "multiply";

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group, new cjs.Rectangle(-1.2,0,687.6,105.8), null);


(lib.escritorio = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_2
	this.instance = new lib.CachedBmp_16();
	this.instance.setTransform(572.8,554.55,0.5,0.5);

	this.instance_1 = new lib.Path_10();
	this.instance_1.setTransform(693.25,826.4,1,1,0,0,0,212.7,21.4);
	this.instance_1.alpha = 0.4219;
	this.instance_1.compositeOperation = "multiply";

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	// Capa_1
	this.instance_2 = new lib.Path_0();
	this.instance_2.setTransform(646.8,174.4,1,1,0,0,0,37.6,63.8);
	this.instance_2.alpha = 0.4609;
	this.instance_2.compositeOperation = "multiply";

	this.instance_3 = new lib.CachedBmp_21();
	this.instance_3.setTransform(610.15,107.9,0.5,0.5);

	this.instance_4 = new lib.Path_7();
	this.instance_4.setTransform(641.4,238.3,1,1,0,0,0,56.6,4.2);
	this.instance_4.alpha = 0.5586;
	this.instance_4.compositeOperation = "multiply";

	this.instance_5 = new lib.CachedBmp_42();
	this.instance_5.setTransform(363.65,35.1,0.5,0.5);

	this.instance_6 = new lib.Path_9_1();
	this.instance_6.setTransform(414.65,188.7,1,1,0,0,0,63.9,21.4);
	this.instance_6.alpha = 0.4219;

	this.instance_7 = new lib.CachedBmp_41();
	this.instance_7.setTransform(201.5,0,0.5,0.5);

	this.instance_8 = new lib.Path_14_1();
	this.instance_8.setTransform(863.35,424.7,1,1,0,0,0,203,126);
	this.instance_8.alpha = 0.5781;

	this.instance_9 = new lib.Path_15();
	this.instance_9.setTransform(575.6,229.2,1,1,0,0,0,442.1,16.7);
	this.instance_9.alpha = 0.5781;

	this.instance_10 = new lib.Path_16_1();
	this.instance_10.setTransform(564.5,254.9,1,1,0,0,0,502.9,44.2);
	this.instance_10.alpha = 0.5781;

	this.instance_11 = new lib.Mesh_0();
	this.instance_11.setTransform(0,223.35);

	this.instance_12 = new lib.Path_18_1();
	this.instance_12.setTransform(190.8,260.2,1,1,0,0,0,186.5,29.8);
	this.instance_12.alpha = 0.6094;
	this.instance_12.compositeOperation = "multiply";

	this.instance_13 = new lib.Path_19_1();
	this.instance_13.setTransform(200.85,252.45,1,1,0,0,0,187.5,32.3);
	this.instance_13.alpha = 0.6914;

	this.instance_14 = new lib.Path_20_1();
	this.instance_14.setTransform(194.05,387.7,1,1,0,0,0,177.7,111);
	this.instance_14.alpha = 0.5781;

	this.instance_15 = new lib.Mesh();
	this.instance_15.setTransform(307.6,209.6);

	this.instance_16 = new lib.CachedBmp_40();
	this.instance_16.setTransform(166.45,35.3,0.5,0.5);

	this.instance_17 = new lib.Path_0_1();
	this.instance_17.setTransform(1423.85,676.45,1,1,0,0,0,46.6,131);
	this.instance_17.alpha = 0.4219;
	this.instance_17.compositeOperation = "multiply";

	this.instance_18 = new lib.Path_1_0();
	this.instance_18.setTransform(1461.45,606.4,1,1,0,0,0,83,78);
	this.instance_18.alpha = 0.5313;
	this.instance_18.compositeOperation = "multiply";

	this.instance_19 = new lib.CachedBmp_39();
	this.instance_19.setTransform(1185.55,202.75,0.5,0.5);

	this.instance_20 = new lib.Group();
	this.instance_20.setTransform(1211.45,802.05,1,1,0,0,0,342.6,52.9);
	this.instance_20.compositeOperation = "multiply";

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.escritorio, new cjs.Rectangle(0,0,1645.6,855.1), null);


(lib.chica = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("ApcXYQg0gIg9grIAAAAQhCgwhchlIAAAAQhahkhei9IAAAAQhTinhMjWIAAAAQhEjCgti3IAAAAQgsixgFhjIAAAAQgKimA5heIAAAAQATgfAigjIAAAAIA1g3IAAAAQAUgYAkgbIAAAAIA+guIAAAAQBLg7AThEIAAAAQAIgfANhMIAAAAIAYiMIAAAAQAhiyAngqIAAAAQAogsBzgQIAAAAIADgBIAAAAIgJgQIAzgHIAAAAQAGAaALAWIAAAAQACAKAEAHIAAAAQAIAPALAKIAAAAQALAKALAEIAAAAIABABIAAAAIgBgBIAAAAQgLgEgLgKIAAAAQgLgKgIgPIAAAAQgEgHgCgKIAAAAQgLgWgGgaIAAAAQgGgbAAgfIAAAAQAAhDAigfIAAAAQAVgTA5geIAAAAQAlgWAxAKIAAAAIASAFIAAAAIgZgBIAAAAQgSAAgLgDIAAAAQALADASAAIAAAAIAZABIAAAAIAFAAIAAAAIgBABIAAAAIAAAAIAAAAQA1goBEgHIAAAAQAVgDAoABIAAAAQAdAAAJgEIAAAAQB6g4BJAGIAAAAQAvAEApAzIAAAAQAYAeAqBDIAAAAQAgAsAGAZIAAAAQAGAUgDA5IAAAAQgCAwgbAlIAAAAQgKANgJAHIAAAAQgIAGgCgCIAAAAIAAgBIAAAAQgBgEAAgOIAAAAQAAAOABAEIAAAAIAAABIAAAAIgDALIAAAAQgJAggBAQIAAAAQgBAGAGAoIAAAAQAEAhgHAgIAAAAQgEATggBMIAAAAQgeBJgEAaIAAAAIgIAzIAAAAQgCAOgIAHIAAAAQgMAKg6ABIAAAAQgUAAgTgCIAAAAQgygEgzgQIAAAAQhKgWhghrIAAAAIgggmIAAAAIABABIAAAAIgBgBIAAAAIgKgJIAAAAIghgjIAAAAIgGgGIAAAAQgrgtgTgaIAAAAQgcgmgQhGIAAAAIgEgQIAAAAIgJACIAAAAIAJgCIAAAAIAEAQIAAAAQAQBGAcAmIAAAAQATAaArAtIAAAAIAGAGIAAAAIAhAjIAAAAIAKAJIAAAAIAgAmIAAAAQBgBrBKAWIAAAAQAzAQAyAEIAAAAQgOACgLAEIAAAAIgLAGIAAAAIgGAEIAAAAIgBAAIAAAAQgKAJgRAVIAAAAIgOATIgBAEIAAAAQgGAhADATIAAAAQADAQAKAOIAAAAIAjAhIAAAAIAkAWIAAAAIgCgDIAAAAQDYB3AIAHIAAAAIgIA1QgHBBAJA3IAAAAQAFAlAeBlIAAAAQAaBUgCAhIAAAAQgEA7gjAsIAAAAQgMANgNAKIAAAAIgLAIIAQBXQATBhASAuIAAAAQAUA1ArA+IAAAAQASAbASAVIAAAAIASAWIAAAAIAVAVIAAAAQAVAVAaAJIAAAAIAJADIAAAAIAFABIAAAAQATAEAZABIAAAAIABABIAAAAIgBgBIAAAAQgZgBgTgEIAAAAIgFgBIAAAAIgJgDIAAAAIB3gyIAAAAIAQACIAAAAIgQgCIAAAAQg0gFgtgBIAAAAQgtAAgtAFIAAAAIgSgWIAAAAQA2gKAxgFIAAAAQCEgNBxgEIAAAAQA5gVAygQIAAAAQEEhSC7gGIAAAAQD4gJAWCJIAAAAQAWCHiUCEIAAAAQg4AyhFAnIAAAAQg8AigsALIAAAAQg5AOilAPIAAAAQjNATipgEIAAAAIg9gCIAAAAQg5hEg0hIIAAAAIgQgWIAAAAIAQAWIAAAAQA0BIA5BEIAAAAIAgAmIAAAAQA8BFAIAEIAAAAQAGADkvBUIAAAAQlGBcgzAUIAAAAQg8AYhHAjIAAAAIg7AfQhNAZghAJIAAAAQgpALggAAIAAAAQgNAAgMgCgApTTeQgvAygQAZIAAAAQgTAeAMAPIAAAAQAVAYAZAEIAAAAQAOADASgCIAAAAQgGgOAAgaIAAAAQgBgnAMg8IAAAAQACgNgBgKIAAAAIgOANgArfSjQgiAZgFAGIAAAAQgRAPgCAQIAAAAQgCARALATIAAAAQALATASAIIAAAAQAVAKAVgIIAAAAQAZgIAUgfIAAAAQAYgjAlggIAAAAQgHAAgHAEIAAAAQgHADgQgEIAAAAQgQgFgMgKIAAAAQgigbAgggIAAAAQARgQAFgWIAAAAQgdAwg2AogAnsR3QgDgNgCgSIAAAAIgBgLIAAAAIgCgZIAAAAIACAZIAAAAIABALIAAAAQACASADANIAAAAgAs5RwQAWAAAXgHIAAAAQBGgXAqhSIAAAAIAIgOIAAAAQgEgSgBgNIAAAAQgDgghYhPIAAAAIg/g6IAAAAIgFgFIAAAAQgmAdgqAaIAAAAQguAdgNATIAAAAQgaAkARA2IAAAAQAVA/AhAlIAAAAQAjAnAogCIAAAAgAn6RNIAAgBIAAAAIAAABgAliNVQAZAcADAuIAAAAQgDgugZgcIAAAAIgFgFIAAAAIAFAFgAl3LYQAhAXABAEIAAAAQAEANAsA1IAAAAQgsg1gEgNIAAAAQgBgEghgXIAAAAQgXgQABgKIAAAAQgBAKAXAQgAy4EOQgDASAMA6IAAAAQAaCCAbBlIAAAAQAyDBAlAaIAAAAQAKAHANADIAAAAIgOgJIAAAAQgugkgMhYIAAAAIgfjmIAAAAQgYiggLgfIAAAAQgFgQgIgJIAAAAQgSAVgDAWgAMRMmIAAAAIAAAAIAAAAgAMSMmIAFgBIAAAAIgFABgAPhMSIhBAGIAAAAIiHANIAAAAIAAAAIAAAAIAAAAICHgNIBBgGIAAAAIApANIAAAAIgpgNIAAAAIAAAAgAIALkQB5ACBQADIAAAAQAXAPAHAPIAAAAQALAYAVAFIAAAAIABABIAAAAIgBgBIAAAAQgVgFgLgYIAAAAQgHgPgXgPIAAAAQhQgDh5gCIAAAAIiFgBIAAAAICFABgAQBMQIBcgJIAAAAQA1gEALgRIAAAAQADgEAAgFIAAAAQAAAFgDAEIAAAAQgLARg1AEIAAAAIhcAJIAAAAIAAAAgAFwLTIgBAAIAAAAIABAAgAF7LSIgLABIAAAAIALgBIAAAAIANgDIAAAAIgNADgAKVLPQgpgRgygMIAAAAQAyAMApARIAAAAIAAAAgAmeKMQAgAMAAAJIAAAAQAAgJgggMIAAAAQgdgKAAgbIAAAAQAAAbAdAKgAulJ7IAAAAIAAAAIAAAAgAukJ7QAIAAAJgDIAAAAQgJADgIAAgAsWIpQg9A3g/AXIAAAAQA/gXA9g3IAAAAQAlgiAcgpIAAAAQgcApglAigAu5J2IgBAAIAAAAIABAAgAwTGgQAFBAAWA6IAAAAQAIAiARAYIAAAAQAQAZAUAJIAAAAQgUgJgQgZIAAAAQgRgYgIgiIAAAAQgWg6gFhAIAAAAQgCghAAgsIAAAAQAAAsACAhgAMWJkIgPgBIAAAAIAPABgAI7JfIAhgBIAAAAIAGAAIAAAAIALAAIAAAAIgLAAIAAAAQANgPAMgLIAAAAQgMALgNAPIAAAAIgGAAIAAAAIghABIAAAAIAAAAgAJxJeIANAAIAAAAIgNAAgAJ/JeIAAAAIAAAAIAAAAgAnCIeIAAAAIAAAAIAAAAgAmTIUIgsAKIAAAAIgDAAIAAAAIADAAIAAAAIAsgKIAAAAQAqgJA3gEIAAAAQg3AEgqAJgAnDIUIAAAAIAAAAIAAAAgAnFH/QAHAEAAAGIAAAAQAAgGgHgEIAAAAIAAAAIAAAAIAAAAgAv+IBIgBAAIAAAAIABAAgAvsG9QgMBCgGACIAAAAQAGgCAMhCIAAAAIAHguIAAAAIgHAugAn0IBIAAAAIAAAAIAAAAgAnyIBIALgDIAAAAIgLADgAnmH+IAAAAgAnkH+QAIgDAIAAIAAAAQgIAAgIADgAn7H8IAAABIAAAAIAAgBIAAAAIAAgBIAAAAIAAABgAwCH7IAAgHIAAAAIAAAHgAnUH7IAAAAIAAAAIAAAAgArMH5IAAAAIAPiqIAvoxIACgYIBBjhIAJAGIAAAAQAMAIALADIAAAAIAGAUQAKAQAhAOIAAAAIAXAIIAAAAIARAIIgRgIIgXgIIAAAAQghgOgKgQIAAAAIgGgUQgLgDgMgIIAAAAIgJgGIAAAAIhBDhIgCAYIhoi2IAAAAIBoC2IAAAAIgvIxIgNgyIAAAAQgJgdgIgaIAAAAQAMhEAAg6IAAAAQAAA6gMBEIAAAAQgJA0gPA5IAAAAIgJAhIAAAAIAJghIAAAAQAPg5AJg0IAAAAQAIAaAJAdIAAAAIANAyIAAAAIgPCqgAnlHJIAAAAIAAAAIAAAAgAoDHHIAAAAIAAAAIAAAAgAoDHHIALgBIAAAAIgLABgAn1HFIgBAAIAAAAIABAAIAAAAIAAAAgAnwHEIAFAAIAAAAIgFAAgAnrHEIAAAAIAAAAIAAAAgAoSG/IAAABIAAAAIAAgBIAAAAIgBgEIAAAAIABAEgAvlGPIAHgTIAAAAIA9iJIAAAAQAPgjBGiOIAAAAIBDiFIAAAAIALgWIAAAAIAGgNIAAAAIABAbIAAAAIgBgbIAAAAQARgpAVhBIAAAAQAPgxALgoIAAAAQgLAogPAxIAAAAQgVBBgRApIAAAAIgGANIAAAAIgLAWIAAAAIhDCFIAAAAQhGCOgPAjIAAAAIg9CJIAAAAIgHATIAAAAIAAAAgAncF6IgBAAIAAAAIABAAgAncF6IAHAAIAAAAIgHAAgAnUF5IAMgFIAAAAQAVgJALAAIAAAAIABAAIAAAAIgBAAIAAAAQgLAAgVAJIAAAAIgMAFIAAAAIAAAAgAoRFuIAAgBIAAAAIAAABgAoTFtIgBgBIAAAAIABABgApYEMQATBHAvAYIAAAAQgvgYgThHIAAAAQgIgeAAgaIAAAAQAAAaAIAegAwSEEIAAAAIAAAAIAAAAgAwREDIAAAAIAAAAIAAAAgAwREDIAAgCIAAAAIAAACgAvvDUQgfASgCAWIAAAAIAAABIAAAAIAAgBIAAAAQACgWAfgSIAAAAIAegNIACADQACADABAIIAAAAIAAANIAAAAIAAgNIAAAAQgBgIgCgDIAAAAIgCgDgAxUCyIgDAUIAAAAIADgUIAAAAQAdgMApgOIAAAAQgpAOgdAMgAwNCxIAAAAIAAAAIAAAAgAwNCwIABgOIAAAAIgBAOgAv4CWIACAAIAAAAIgCAAgAv2CWIABgBIAAAAIgBABgAv0CVQAOgFAPAAIAAAAQgPAAgOAFgAvBCTIgBgBIAAAAIABABgAzXg8QgGBbALBRIAAAAQADAXAJALIAAAAIgGh/IAAAAQgDhbABg8IAAAAQgGAigDAmgAvWCQIgBAAIAAAAIABAAgAuFlzQhvBBgUAWIAAAAQgTAVgEATIAAAAIgCAFIAAAAIgMBXQgNBfgDAnIAAAAQgDAtgNBiIAAAAQANhiADgtIAAAAQADgnANhfIAAAAIAMhXIACgFIAAAAQAEgTATgVIAAAAQAUgWBvhBIAAAAQA6giAwgbIAAAAQACALAAALIAAAAQAAALAUCjIAAAAQgUijAAgLIAAAAQAAgLgCgLIAAAAQgwAbg6AigAl6htIgBAAIAAAAIABAAgAl6htQAnAAAMgHIAAAAQgMAHgnAAgAnRhyIgCAAIAAAAIACAAgAnWhzIADABIAAAAIgDgBIAAAAIgigDIAAAAIAiADgAwai5QAKAjAPAjIAAAAQgPgjgKgjIAAAAQgIgcAAgKIAAAAQAAAKAIAcgAhGlnQgaAhhNBIIAAAAQh0BvglAaIAAAAIgBABIAAAAIABgBIAAAAQAlgaB0hvIAAAAQBNhIAaghIAAAAQAOgSAAgGIAAAAQAAAGgOASgAwgjjIgBgHIAAAAIABAHgAvajtQAQgEATAAIAAAAQgTAAgQAEgAuejvIgCAAIAAAAIACAAgAuhjvIgBAAIAAAAIABAAgAu3jxIAAAAIAAAAIAAAAgAtznoQhQAWgVAIIAAAAQgqARgwAhIAAAAQgTAMgaAbIAAAAQgYAZgTAcIAAAAIAXgNIAAAAIAjgTIAAAAICphdIAAAAIBbgyIAAAAIgLgBIAAAAQgNAAgPAEgAp8pKQAIAxAAAKIAAAAQABAEACAFIAAAAQgCgFgBgEIAAAAQAAgKgIgxIAAAAQgGgfAAgWIAAAAQAAAWAGAfgAohpuIgeBoIAehoIAwhfIAqAPQAMgfAAgYIAAAAQAAAYgMAfIAAAAIgqgPgAr2xBQgVAIgYAPIAAAAQgvAegOAnIAAAAQgOAkgVBuIAAAAIgaCTIAAAAQgJAxgZBUIAAAAIgFAJQgFALABAHIAAAAQACAWA7gZIAAAAQApgSBPgQIAAAAQgDgYgHggIAAAAQgJgrACgeIAAAAQABgZALgdIAAAAQAIgXgFgzIAAAAQgEgggNhBIAAAAQgIgpAPgdIAAAAQAEgKAGgHIAAAAIAFgFIAAAAIAoBGQgDgegCgjIAAAAQgBgsAEgZIAAAAIgMACgAl3qhIAmANIgmgNIAAAAgAl2qiIADgBIAAAAIgDABgAlzqjIACgBIAAAAIgCABgAlxqkIALgEIAAAAIgLAEgAllqoIAFgBIAAAAIgFABgAlgqpIAHgBIAAAAIgHABgAlTqqIAAAAIAAAAIAAAAgAlWqqIgBAAIAAAAIABAAgAp8ryIAAAWIAAAAIAAgWIAAAAIgBgMIAAAAIABAMgApEtCQgBARgDANIAAAAQADgNABgRIAAAAIABgaIAAAAIgBAagAtAxfQgKAEgNAJIAAAAQgaAUgQAfIAAAAQgPAggVBwIAAAAQgKA4gHAyIAAAAQAHgyAKg4IAAAAQAVhwAPggIAAAAQAQgfAagUIAAAAQANgJAKgEIAAAAIAAAAgAqIu+IAKAoQAJArAAAXIAAAAQAAgXgJgrIAAAAIgKgoQgCgIAHAAIAAAAQgHAAACAIgAqCvGIgBAAIAAAAIABAAgAqDvGIAAAAIAAAAIAAAAgAiVvNIAAAAIAAAAIAAAAgAiUvNQATAAAYgDIAAAAQgYADgTAAgAiXvNIgCAAIAAAAIACAAgAhlwZQgiBDgSAJIAAAAQASgJAihDIAAAAQARgiANgfIAAAAQAPACAJAFIAAAAIAGAEIAAAAIgGgEIAAAAQgJgFgPgCIAAAAQgNAfgRAigAhpvQIADAAIAAAAIgDAAgAnowvQAOAEAIAOIAAAAQAGAJADAXIAAAAIADAVIAAAAQADgLAGgOIAAAAQAMgbARgMIAAAAQARgOA5g0IAAAAIBWhQIAAAAQAcgaAigTIAAAAQARgKAMgEIAAAAQgMAEgRAKIAAAAQgiATgcAaIAAAAIhWBQIAAAAQg5A0gRAOIAAAAQgRAMgMAbIAAAAQgGAOgDALIAAAAIgDgVIAAAAQgDgXgGgJIAAAAQgIgOgOgEIAAAAIgBAAIAAAAIABAAgAAdv8IAAAAIAAAAIAAAAgAAev9IABAAIAAAAIgBAAgAAgv+IABAAIAAAAIgBAAgAinwFIAAAAIAAAAIAAAAgAimwFIABAAIAAAAIgBAAgAoJwgQgIAKAAARIAAAAQAAgRAIgKIAAAAQAMgPAOAAIAAAAQgOAAgMAPgAAbwSQgCABAAAFIAAAAIAAAFIAAAAIAAgFIAAAAQAAgFACgBIAAAAQAJgCAEACIAAAAQACABADADIAAAAQAAAAAAAAQABABAAAAQAAAAAAABQAAAAAAAAIAAAAQAAAAAAAAQAAgBAAAAQAAAAgBgBQAAAAAAAAIAAAAQgDgDgCgBIAAAAIgFgBIAAAAIgIABgAipwHIAAgBIAAAAIAAABgAinwdQgDADAAAGIAAAAQAAgGADgDIAAAAQALgDAJAAIAAAAQgJAAgLADgAh+wbIACACIAAAAIgCgCIAAAAIAAAAgAiSwgIAAAAIAAAAIAAAAgAmGwuIASgHQAWgJAWgMIAAAAQBGglArgxIAAAAQAsgxAdgqIAAAAQAPgVAGgLIAAAAIABAEQACAFAFAFIAAAAQARAQAqARIAAAAQA1AUAhAgIAAAAQAkAhAAAgIAAAAQAAgggkghIAAAAQghggg1gUIAAAAQgqgRgRgQIAAAAQgFgFgCgFIAAAAIgBgEQgGALgPAVIAAAAQgdAqgsAxIAAAAQgrAxhGAlIAAAAQgWAMgWAJIAAAAIgSAHgAnvwvIAAAAIAAAAIAAAAgApowzIgBAAIAAAAIABAAgApowzIAEAAIAAAAIgEAAgAp6xnIAEARIAAAAQACAJAAAKIAAAAQAAgKgCgJIAAAAIgEgRIAAAAIgBgOIAAAAIABAOgAqJxEQgSgYABgcIAAAAQgBAcASAYIAAAAIAAAAgApuxOIAAgNIAAAAIAAANIAAAAIAAAAgAqDxRQADgUAFgTIAAAAQgFATgDAUIAAAAQgGgSAAgSIAAAAQAAASAGASgAslxbIAAADIAAAAIAAgDIAAAAIAAAAgAs/xgIAAAAIAAAAIAAAAgAs+xgQAJgFAGAAIAAAAQgGAAgJAFgAsvxlIAAAAIAAAAIAAAAgAphxoIAAgBIAAAAIAAABIAAAAIAAAAgAqNxsQAAgUAHgOIAAAAQgHAOAAAUgAo70XQgJATgOAmIAAAAIgPAjIAAAAQgJAVgFAOIAAAAQgGAVAAASIAAAAQAAgSAGgVIAAAAQAFgOAJgVIAAAAIAPgjIAAAAQAOgmAJgTIAAAAQAOggATgRIAAAAQgTARgOAggAplx8QAAgLAFgJIAAAAQgFAJAAALgAqqyLQACgVATgSIAAAAQANgMAYgNIAAAAQgYANgNAMIAAAAQgTASgCAVIAAAAIgGgQgApMyfIAmgqIgmAqIAAAAgApK0oQgLAOgJAUIAAAAIgEAIIAAAAIAEgIIAAAAQAJgUALgOIAAAAQAZglAjgMIAAAAQgjAMgZAlgApY1XIBTgOg");
	mask.setTransform(226.1743,163.3046);

	// Capa_2
	this.instance = new lib.sombra_chica();
	this.instance.setTransform(273,212,1,1,0,0,0,201,212);
	this.instance.alpha = 0.8789;
	this.instance.compositeOperation = "multiply";

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Capa_1
	this.instance_1 = new lib.Path_6();
	this.instance_1.setTransform(193.65,88.45,0.4383,0.4383,0,0,0,3.4,2.9);
	this.instance_1.alpha = 0.2695;

	this.instance_2 = new lib.Path_1_1();
	this.instance_2.setTransform(191.7,82.2,0.4383,0.4383,0,0,0,4.1,2);
	this.instance_2.alpha = 0.2695;

	this.instance_3 = new lib.Path_2();
	this.instance_3.setTransform(187.8,76.55,0.4383,0.4383,0,0,0,6.6,5.4);
	this.instance_3.alpha = 0.2695;

	this.instance_4 = new lib.Path_3();
	this.instance_4.setTransform(325.1,278.75,0.4383,0.4383,0,0,0,64.7,94.9);
	this.instance_4.alpha = 0.1797;
	this.instance_4.compositeOperation = "multiply";

	this.instance_5 = new lib.Path_4();
	this.instance_5.setTransform(448.15,400.9,0.4383,0.4383,0,0,0,43.4,27.6);
	this.instance_5.alpha = 0.6406;

	this.instance_6 = new lib.Path_5();
	this.instance_6.setTransform(468.25,409.7,0.4383,0.4383,0,0,0,89.5,19.9);
	this.instance_6.alpha = 0.6016;
	this.instance_6.compositeOperation = "multiply";

	this.instance_7 = new lib.CachedBmp_38();
	this.instance_7.setTransform(202.85,110.85,0.5,0.5);

	this.instance_8 = new lib.Path_8_1();
	this.instance_8.setTransform(225.25,141.2,0.4383,0.4383,0,0,0,27.2,48.7);
	this.instance_8.alpha = 0.4102;

	this.instance_9 = new lib.CachedBmp_37();
	this.instance_9.setTransform(98.95,232.95,0.5,0.5);

	this.instance_10 = new lib.Path_14();
	this.instance_10.setTransform(142.9,383.4,0.4383,0.4383,0,0,0,27.6,28.1);
	this.instance_10.alpha = 0.5195;

	this.instance_11 = new lib.CachedBmp_36();
	this.instance_11.setTransform(133.15,357.75,0.5,0.5);

	this.instance_12 = new lib.Path_17();
	this.instance_12.setTransform(177.05,383.6,0.4383,0.4383,0,0,0,76.5,40.5);
	this.instance_12.alpha = 0.5781;

	this.instance_13 = new lib.CachedBmp_12();
	this.instance_13.setTransform(270.8,365.2,0.5,0.5);

	this.instance_14 = new lib.Path_19();
	this.instance_14.setTransform(297.55,383.4,0.4383,0.4383,0,0,0,10.7,35.5);
	this.instance_14.compositeOperation = "multiply";

	this.instance_15 = new lib.Path_20();
	this.instance_15.setTransform(267.8,385.95,0.4383,0.4383,0,0,0,38.2,28.1);
	this.instance_15.alpha = 0.5781;

	this.instance_16 = new lib.CachedBmp_35();
	this.instance_16.setTransform(252.5,363.3,0.5,0.5);

	this.instance_17 = new lib.Path_23();
	this.instance_17.setTransform(291.15,374.45,0.4383,0.4383,0,0,0,43.8,21.4);
	this.instance_17.alpha = 0.5781;

	this.instance_18 = new lib.CachedBmp_10();
	this.instance_18.setTransform(196.25,55,0.5,0.5);

	this.instance_19 = new lib.Path_25();
	this.instance_19.setTransform(205.95,57.2,0.4383,0.4383,0,0,0,13.6,14.1);
	this.instance_19.alpha = 0.5;

	this.instance_20 = new lib.Path_26();
	this.instance_20.setTransform(232.2,60.3,0.4383,0.4383,0,0,0,4.8,13.6);
	this.instance_20.alpha = 0.5;

	this.instance_21 = new lib.Path_27();
	this.instance_21.setTransform(216.4,58.95,0.4383,0.4383,0,0,0,12.8,16.3);
	this.instance_21.alpha = 0.5;

	this.instance_22 = new lib.CachedBmp_34();
	this.instance_22.setTransform(161.25,46.8,0.5,0.5);

	this.instance_23 = new lib.Path_35();
	this.instance_23.setTransform(174.4,67.25,0.4383,0.4383,0,0,0,25.7,36.2);
	this.instance_23.alpha = 0.4609;

	this.instance_24 = new lib.CachedBmp_33();
	this.instance_24.setTransform(170.05,50.55,0.5,0.5);

	this.instance_25 = new lib.Path_38();
	this.instance_25.setTransform(223.4,234.05,0.4383,0.4383,0,0,0,73.8,27.2);
	this.instance_25.alpha = 0.4102;

	this.instance_26 = new lib.Path_39();
	this.instance_26.setTransform(213.65,204.85,0.4383,0.4383,0,0,0,66,38.8);
	this.instance_26.alpha = 0.4102;

	this.instance_27 = new lib.CachedBmp_32();
	this.instance_27.setTransform(131.05,50.65,0.5,0.5);

	this.instance_28 = new lib.Path_44();
	this.instance_28.setTransform(246.65,341.3,0.4383,0.4383,0,0,0,62.4,86.4);
	this.instance_28.alpha = 0.5781;

	this.instance_29 = new lib.CachedBmp_6();
	this.instance_29.setTransform(211.3,300.65,0.5,0.5);

	this.instance_30 = new lib.Path_46();
	this.instance_30.setTransform(289.9,232.4,0.4383,0.4383,0,0,0,90.5,25.2);
	this.instance_30.alpha = 0.3984;
	this.instance_30.compositeOperation = "multiply";

	this.instance_31 = new lib.Path_47();
	this.instance_31.setTransform(262.05,290.7,0.4383,0.4383,0,0,0,203.8,60.2);
	this.instance_31.alpha = 0.1797;
	this.instance_31.compositeOperation = "multiply";

	this.instance_32 = new lib.CachedBmp_31();
	this.instance_32.setTransform(123.45,23.3,0.5,0.5);

	this.instance_33 = new lib.Path_66();
	this.instance_33.setTransform(139.25,174.2,0.4383,0.4383,0,0,0,39.6,92.9);
	this.instance_33.alpha = 0.3984;
	this.instance_33.compositeOperation = "multiply";

	this.instance_34 = new lib.CachedBmp_4();
	this.instance_34.setTransform(121.9,266.85,0.5,0.5);

	this.instance_35 = new lib.Path_68();
	this.instance_35.setTransform(254.5,270.35,0.4383,0.4383,0,0,0,183.3,59.9);
	this.instance_35.alpha = 0.2109;
	this.instance_35.compositeOperation = "multiply";

	this.instance_36 = new lib.Path_69();
	this.instance_36.setTransform(175.75,194.55,0.4383,0.4383,0,0,0,48.5,190.1);
	this.instance_36.alpha = 0.4102;

	this.instance_37 = new lib.CachedBmp_30();
	this.instance_37.setTransform(114.95,50.65,0.5,0.5);

	this.instance_38 = new lib.Path_75();
	this.instance_38.setTransform(229.75,60.05,0.4383,0.4383,0,0,0,2.4,2.6);
	this.instance_38.alpha = 0.5;

	this.instance_39 = new lib.Path_76();
	this.instance_39.setTransform(211.35,59.05,0.4383,0.4383,0,0,0,5.2,3.2);
	this.instance_39.alpha = 0.5;

	this.instance_40 = new lib.Path_77();
	this.instance_40.setTransform(229.85,60.05,0.4383,0.4383,0,0,0,3.6,4.4);
	this.instance_40.alpha = 0.7813;
	this.instance_40.compositeOperation = "multiply";

	this.instance_41 = new lib.Path_78();
	this.instance_41.setTransform(211.95,58.8,0.4383,0.4383,0,0,0,9,4.2);
	this.instance_41.alpha = 0.7813;
	this.instance_41.compositeOperation = "multiply";

	this.instance_42 = new lib.CachedBmp_29();
	this.instance_42.setTransform(93.6,13.5,0.5,0.5);

	this.instance_43 = new lib.Path_124();
	this.instance_43.setTransform(184.7,172.95,0.4383,0.4383,0,0,0,177.2,297.9);
	this.instance_43.alpha = 0.5;
	this.instance_43.compositeOperation = "multiply";

	this.instance_44 = new lib.CachedBmp_1();
	this.instance_44.setTransform(87.9,46.55,0.5,0.5);

	this.instance_45 = new lib.ClipGroup();
	this.instance_45.setTransform(167.5,233.35,0.4383,0.4383,0,0,0,617.6,622.9);
	this.instance_45.alpha = 0.6914;

	this.instance_46 = new lib.Path_125();
	this.instance_46.setTransform(215,397.85,0.4383,0.4383,0,0,0,236.8,38);
	this.instance_46.alpha = 0.4219;
	this.instance_46.compositeOperation = "multiply";

	this.instance_47 = new lib.Path_126();
	this.instance_47.setTransform(274.7,402.85,0.4383,0.4383,0,0,0,626.7,68.4);
	this.instance_47.alpha = 0.4219;
	this.instance_47.compositeOperation = "multiply";

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_47},{t:this.instance_46},{t:this.instance_45},{t:this.instance_44},{t:this.instance_43},{t:this.instance_42},{t:this.instance_41},{t:this.instance_40},{t:this.instance_39},{t:this.instance_38},{t:this.instance_37},{t:this.instance_36},{t:this.instance_35},{t:this.instance_34},{t:this.instance_33},{t:this.instance_32},{t:this.instance_31},{t:this.instance_30},{t:this.instance_29},{t:this.instance_28},{t:this.instance_27},{t:this.instance_26},{t:this.instance_25},{t:this.instance_24},{t:this.instance_23},{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.chica, new cjs.Rectangle(0,-4.9,549.4,437.5), null);


(lib.pierna = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_2
	this.instance = new lib.Interpolación2("synched",0);
	this.instance.setTransform(169.55,450.05);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({rotation:-7.7267,x:213.4,y:441.85},17).to({regX:0.1,regY:0.1,rotation:-10.4656,x:213.5,y:441.95},3).to({regX:0,regY:0,rotation:0,x:169.55,y:450.05},12).to({startPosition:0},1).wait(1));

	// Capa_1
	this.instance_1 = new lib.Interpolación1("synched",0);
	this.instance_1.setTransform(45.8,17.7,1,1,0,0,0,-91.7,-229.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({regY:-229.1,rotation:-5.1924,y:17.8},17).to({startPosition:0},3).to({regY:-229.2,rotation:0,y:17.7},12).to({startPosition:0},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-0.6,316.8,488.3);


// stage content:
(lib.chica_escritorio_sentada = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.pierna();
	this.instance.setTransform(513.15,464.05,0.4383,0.4383,0,0,0,57.2,18.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_1
	this.instance_1 = new lib.chica();
	this.instance_1.setTransform(386,470.2,1,1,0,0,0,223,233.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// Layer_1
	this.instance_2 = new lib.escritorio();
	this.instance_2.setTransform(779.6,522.05,0.4383,0.4383,0,0,0,822.8,427.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	// Layer_1
	this.instance_3 = new lib.ventana();
	this.instance_3.setTransform(797.7,217.3,1,1,0,0,0,276.8,207.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1));

	// stageBackground
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("rgba(0,0,0,0)").ss(1,1,1,3,true).p("Ehljg5zMDLHAAAMAAABznMjLHAAAg");
	this.shape.setTransform(640,360);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("EhljA50MAAAhznMDLHAAAMAAABzng");
	this.shape_1.setTransform(640,360);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(629,349,662,382);
// library properties:
lib.properties = {
	id: '5ECF295F60BB4E379EDB4EB83BC13890',
	width: 1280,
	height: 720,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/chica_escritorio_sentada_atlas_1.png?1651090061947", id:"chica_escritorio_sentada_atlas_1"},
		{src:"images/chica_escritorio_sentada_atlas_2.png?1651090061947", id:"chica_escritorio_sentada_atlas_2"},
		{src:"images/chica_escritorio_sentada_atlas_3.png?1651090061947", id:"chica_escritorio_sentada_atlas_3"},
		{src:"images/chica_escritorio_sentada_atlas_4.png?1651090061948", id:"chica_escritorio_sentada_atlas_4"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['5ECF295F60BB4E379EDB4EB83BC13890'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;